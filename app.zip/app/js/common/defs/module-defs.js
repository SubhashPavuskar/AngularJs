(function () {
    'use strict';

    var definitions = {
        initializeModule: function (loggerService, globalViewModel) {
            var validation = loggerService && globalViewModel;

            if (validation) {
                globalViewModel.appInitTime = new Date();
                loggerService.log('Common Module Initialized!');
            }
        }
    };

    module.exports = definitions;
})();