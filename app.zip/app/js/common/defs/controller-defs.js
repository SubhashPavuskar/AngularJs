(function () {
    'use strict';

    var definitions = {
        homeViewController: function (viewModel, subHeadingService) {
            var validation = viewModel && subHeadingService;

            if (validation) {
                subHeadingService.getSubHeadings().then(
                    function (data) {
                        if (data) {
                            viewModel.subHeadings = data;
                        }
                    },
                    function (error) {
                        if (error) {
                            viewModel.errorMessage = "Error Occurred, Details : " +
                                JSON.stringify(error);

                            throw error;
                        }
                    });
            }
        },
        navigationViewController: function (viewModel, globalViewModel) {
            var validation = viewModel && globalViewModel;

            if (validation) {
                globalViewModel.$watch('isAuthenticated',
                    function (newValue) {
                        viewModel.authenticationStatus = newValue;
                    });
            }
        }
    };

    module.exports = definitions;
})();