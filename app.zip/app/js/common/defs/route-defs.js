(function () {
    'use strict';

    var states = {
        home: {
            url: '/home',
            name: 'home',
            controller: 'homeViewController'
        }
    };

    var definitions = {
        initializeCommonRouter: function (stateProvider, urlRouterProvider, templateUrls) {
            var validation = stateProvider &&
                urlRouterProvider && templateUrls;

            if (validation) {
                stateProvider.state(states.home.name, {
                    url: states.home.url,
                    templateUrl: function () {
                        return templateUrls.home;
                    },
                    controller: states.home.controller
                });

                urlRouterProvider.otherwise(states.home.name);
            }
        }
    };

    module.exports = definitions;
})();