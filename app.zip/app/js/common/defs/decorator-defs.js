(function () {
    'use strict';

    var CACHE_CONTAINER = "subHeadingsCacheContainer";
    var CACHE_ITEM_KEY = "subHeadingsCache";

    function decorateSubHeadingService(delegateService,
                                       promiseService, cacheService, loggerService) {
        var validation = delegateService && promiseService &&
            cacheService && loggerService;

        if (validation) {
            var realServiceReference = delegateService.getSubHeadings;

            delegateService.getSubHeadings = function () {
                var subHeadingsCacheContainer = cacheService(CACHE_CONTAINER);
                var subHeadingsCache = subHeadingsCacheContainer.get(CACHE_ITEM_KEY);
                var deferred = promiseService.defer();

                if (subHeadingsCache) {
                    loggerService.info("Cache Found!");

                    deferred.resolve(subHeadingsCache);
                } else {
                    loggerService.info("Cache Not Found!");

                    realServiceReference().then(
                        function (data) {
                            if (data) {
                                subHeadingsCacheContainer.put(CACHE_ITEM_KEY, data);

                                deferred.resolve(data);
                            }
                        },
                        function (error) {
                            deferred.reject(error);
                        });
                }

                return deferred.promise;
            };
        }

        return delegateService;
    }

    var definitions = {
        configureDecorators: function (provideService) {
            if (provideService) {
                var subHeadingDecorator =
                    [
                        '$delegate',
                        '$q',
                        '$cacheFactory',
                        '$log',
                        decorateSubHeadingService
                    ];

                provideService.decorator('subHeadingService', subHeadingDecorator);
            }
        }
    };

    module.exports = definitions;
})();