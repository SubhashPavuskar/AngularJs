(function () {
    'use strict';

    require('./config');

    var ngModuleName = 'com.gs.modules.common.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.common.config'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var headerDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.headerDirective
        ];

    var footerDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.footerDirective
        ];

    var navigationDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.navigationDirective
        ];

    var subHeadingViewerDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.subHeadingViewerDirective
        ];

    moduleObject.directive('gsCommonHeader', headerDirectiveDefinition);
    moduleObject.directive('gsCommonFooter', footerDirectiveDefinition);
    moduleObject.directive('gsCommonNavigation', navigationDirectiveDefinition);
    moduleObject.directive('subHeadingViewer', subHeadingViewerDirectiveDefinition);
})();