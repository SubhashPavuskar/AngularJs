/**
 * Created by Ramkumar on 10/4/2016.
 */
(function () {
    'use strict';

    var definitions = {
        initializeApp: function(loggerService) {
            if(loggerService) {
                loggerService.log('Application Initialized!');
            }
        }
    };

    module.exports = definitions;
})();