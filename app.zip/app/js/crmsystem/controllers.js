(function () {
    'use strict';

    require('./services');

    var ngModuleName = 'com.gs.modules.crmsystem.controllers';
    var angular = require('angular');
    var definitions = require('./defs/controller-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);
    var crmSystemHomeViewControllerDefinition =
        [
            '$scope',
            'customerService',
            definitions.crmSystemHomeViewController
        ];

    var crmSystemDashboardHomeViewControllerDefinition =
        [
            '$scope',
            '$stateParams',
            '$q',
            '$state',
            'customerService',
            'orderService',
            'orderDataTransformerService',
            'crmSystemEvents',
            definitions.crmSystemDashboardHomeViewController
        ];

    var stockViewerControllerDefinition =
        [
            '$scope',
            '$interval',
            '$window',
            'stockQuoteService',
            definitions.stockViewerController
        ];

    var dashboardSwitchPanelViewControllerDefinition =
        [
            '$scope',
            'crmSystemEvents',
            definitions.dashboardSwitchPanelViewController
        ];

    moduleObject.controller('crmSystemHomeViewController', crmSystemHomeViewControllerDefinition);
    moduleObject.controller('crmSystemDashboardHomeViewController', crmSystemDashboardHomeViewControllerDefinition)
    moduleObject.controller('stockViewerController', stockViewerControllerDefinition)
    moduleObject.controller('dashboardSwitchPanelViewController', dashboardSwitchPanelViewControllerDefinition)
})();