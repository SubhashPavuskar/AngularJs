(function () {
    'use strict';

    require('./services');

    var ngModuleName = 'com.gs.modules.crmsystem.controllers';
    var angular = require('angular');
    var definitions = require('./defs/controller-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);
    var crmSystemHomeViewControllerDefinition =
        [
            '$scope',
            'customerService',
            definitions.crmSystemHomeViewController
        ];

    moduleObject.controller('crmSystemHomeViewController', crmSystemHomeViewControllerDefinition);
})();