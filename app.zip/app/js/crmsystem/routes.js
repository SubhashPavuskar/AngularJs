(function () {
    'use strict';

    require('angular-ui-router');
    require('./controllers');
    require('./config');

    var ngModuleName = 'com.gs.modules.crmsystem.routes';
    var angular = require('angular');
    var definitions = require('./defs/route-defs');

    var ngDependencies =
        [
            'ui.router',
            'com.gs.modules.crmsystem.controllers',
            'com.gs.modules.crmsystem.config'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var crmSystemRouterDefinition =
        [
            '$stateProvider',
            'crmSystemViewTemplateUrls',
            definitions.configureCrmSystemRouter
        ];

    moduleObject.config(crmSystemRouterDefinition);
})();