(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        customerViewerDirective: function (templateUrls) {
            var scope = {
                customerInfo: '='
            };

            return directiveUtils.createDirective(templateUrls.customerViewer, scope);
        },
        customerDetailViewerDirective: function (templateUrls) {
            var scope = {
                customerDetail: '='
            };

            return directiveUtils.createDirective(templateUrls.customerDetailViewer, scope);
        },
        customerSearchPanelDirective: function (templateUrls) {
            var scope = {
                searchString: '='
            };

            return directiveUtils.createDirective(templateUrls.customerSearchPanel, scope);
        },
        orderViewerDirective: function (templateUrls) {
            var scope = {
                ordersList: '='
            };

            return directiveUtils.createDirective(templateUrls.orderViewer, scope);
        },
        orderChartViewerDirective: function (templateUrls) {
            var scope = {
                ordersData: '='
            };

            return directiveUtils.createDirective(templateUrls.orderChartViewer, scope);
        },
        stockViewerDirective: function (templateUrls) {
            var scope = {
                refreshInterval: '@',
                customerId: '='
            };

            var controller = 'stockViewerController';

            return directiveUtils.createDirective(templateUrls.stockViewer, scope, controller);
        },
        stockQuoteHistoryViewerDirective: function (templateUrls) {
            var scope = {
                historyData: '='
            };

            return directiveUtils.createDirective(templateUrls.stockQuoteHistoryViewer, scope);
        },
        dashboardSwitchPanelViewerDirective: function(templateUrls) {
            var scope = null;
            var controller = 'dashboardSwitchPanelViewController';

            return directiveUtils.createDirective(templateUrls.dashboardSwitchPanelViewer, scope, controller);
        }
    };

    module.exports = definitions;
})();