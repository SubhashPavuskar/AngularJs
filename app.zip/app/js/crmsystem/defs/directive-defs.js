(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        customerViewerDirective: function (templateUrls) {
            var scope = {
                customerInfo: '='
            };

            return directiveUtils.createDirective(templateUrls.customerViewer, scope);
        }
    };

    module.exports = definitions;
})();