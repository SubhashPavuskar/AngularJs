(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        customerViewerDirective: function (templateUrls) {
            var scope = {
                customerInfo: '='
            };

            return directiveUtils.createDirective(templateUrls.customerViewer, scope);
        },
        customerDetailViewerDirective: function (templateUrls) {
            var scope = {
                customerDetail: '='
            };

            return directiveUtils.createDirective(templateUrls.customerDetailViewer, scope);
        },
        customerSearchPanelDirective: function (templateUrls) {
            var scope = {
                searchString: '='
            };

            return directiveUtils.createDirective(templateUrls.customerSearchPanel, scope);
        },
        orderViewerDirective: function (templateUrls) {
            var scope = {
                ordersList: '='
            };

            return directiveUtils.createDirective(templateUrls.orderViewer, scope);
        },
        orderChartViewerDirective: function (templateUrls) {
            var scope = {
                ordersData: '='
            };

            return directiveUtils.createDirective(templateUrls.orderChartViewer, scope);
        },
        stockViewerDirective: function (templateUrls) {
            var scope = {
                refreshInterval: '@',
                customerId: '='
            };

            var controller = 'stockViewerController';

            return directiveUtils.createDirective(templateUrls.stockViewer, scope, controller);
        },
        stockQuoteHistoryViewerDirective: function (templateUrls) {
            var scope = {
                historyData: '='
            };

            return directiveUtils.createDirective(templateUrls.stockQuoteHistoryViewer, scope);
        },
        dashboardSwitchPanelViewerDirective: function (templateUrls) {
            var scope = null;
            var controller = 'dashboardSwitchPanelViewController';

            return directiveUtils.createDirective(templateUrls.dashboardSwitchPanelViewer, scope, controller);
        },
        creditLimitValidationDirective: function () {
            var templateUrl = null;
            var scope = {
                minimumLimit: '=',
                maximumLimit: '='
            };

            var directiveDefinition = directiveUtils.createDirective(
                templateUrl, scope);

            directiveDefinition.require = 'ngModel';
            directiveDefinition.link =
                function (scope, domElement, attributes, model) {
                    model.$validators.creditLimitValidation =
                        function (modelValue) {
                            var status = false;

                            if (modelValue) {
                                status = modelValue >= scope.minimumLimit &&
                                    modelValue <= scope.maximumLimit;
                            }

                            return status;
                        };
                };

            return directiveDefinition;
        }
    };

    module.exports = definitions;
})();