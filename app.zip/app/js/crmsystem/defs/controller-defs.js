(function () {
    'use strict';

    var UPPER_LIMIT = 6;
    var LOWER_LIMIT = 0;
    var UNIT_VALUE = '₹ ';
    var PRECISION = 2;
    var COLOR_RANGES = [
        {
            min: 0,
            max: 1.5,
            color: '#DEDEDE'
        },
        {
            min: 1.5,
            max: 2.5,
            color: '#8DCA2F'
        },
        {
            min: 2.5,
            max: 3.5,
            color: '#FDC702'
        },
        {
            min: 3.5,
            max: 4.5,
            color: '#FF7700'
        },
        {
            min: 4.5,
            max: 6.0,
            color: '#C50200'
        }
    ];
    var DASHBOARD_VIEW = "crmSystemDashboardHome";
    var MINIMUM_LIMIT = 1000;
    var MAXIMUM_LIMIT = 10000;
    var PHONE_EXPRESSION = /^\d{3,5}-\d{6,8}$/;
    var EVENT_NAME = "newCustomerRecord";

    function handleError(viewModel, error) {
        if (viewModel && error) {
            viewModel.errorMessage = 'Error Occurred, Details : ' +
                JSON.stringify(error);

            throw error;
        }
    }

    var definitions = {
        crmSystemHomeViewController: function (viewModel, customerService, notificationService) {
            var validation = viewModel && customerService && notificationService;

            if (validation) {

                notificationService.registerCallback(EVENT_NAME, function (notificationData) {
                    if (notificationData && viewModel.customers) {
                        var newCustomerRecord = notificationData;

                        viewModel.$apply(function () {
                            viewModel.customers.push(newCustomerRecord);
                        });
                    }
                });

                customerService.getCustomers().then(
                    function (data) {
                        if (data) {
                            viewModel.customers = data;
                        }
                    },
                    function (error) {
                        handleError(viewModel, error);
                    });
            }
        },
        crmSystemDashboardHomeViewController: function (viewModel, stateParameters, promiseService,
                                                        stateService,
                                                        customerService, orderService,
                                                        ordersChartDataTransformService, crmSystemEvents) {
            var validation = viewModel && stateParameters && promiseService && stateService &&
                customerService && orderService && ordersChartDataTransformService && crmSystemEvents;

            if (validation) {

                viewModel.$on(crmSystemEvents.DASHBOARD_SWITCH_EVENT,
                    function (eventInfo, eventData) {
                        if (eventData) {
                            var selectedCustomerId = eventData;

                            stateService.go(DASHBOARD_VIEW, {
                                customerId: selectedCustomerId
                            });
                        }
                    });

                var selectedCustomerId = stateParameters.customerId;

                var customerPromise = customerService.getCustomer(selectedCustomerId);
                var orderPromise = orderService.getOrders(selectedCustomerId);

                promiseService.all([customerPromise, orderPromise]).then(
                    function (results) {
                        if (results) {
                            viewModel.customer = results[0];
                            viewModel.orders = results[1];
                            viewModel.ordersChartData = ordersChartDataTransformService.transform(results[1]);
                        }
                    },
                    function (error) {
                        handleError(viewModel, error);
                    });
            }
        },
        stockViewerController: function (viewModel, interval, browser, stockQuoteService) {
            var validation = viewModel &&
                interval && browser && stockQuoteService;

            var initializeQuotation = function () {
                var quotation = stockQuoteService.getStockQuote(viewModel.customerId);

                viewModel.quotation = quotation;
                viewModel.stockQuoteHistory.unshift({
                    time: new Date(),
                    quotation: quotation
                });

                if (viewModel.gaugeData) {
                    viewModel.gaugeData.value = Math.floor(
                        quotation % UPPER_LIMIT);
                }
            };

            var timerObject = null;

            if (validation) {
                viewModel.gaugeData = {
                    upperLimit: UPPER_LIMIT,
                    lowerLimit: LOWER_LIMIT,
                    valueUnit: UNIT_VALUE,
                    precision: PRECISION,
                    ranges: COLOR_RANGES,
                    value: 0
                };
                viewModel.stockQuoteHistory = [];

                viewModel.$watch('refreshInterval', function (newValue) {
                    if (timerObject) {
                        browser.clearInterval(timerObject.$$intervalId);
                    }

                    timerObject = interval(initializeQuotation, viewModel.refreshInterval);
                });
            }
        },
        dashboardSwitchPanelViewController: function (viewModel, crmSystemEvents) {
            var validation = viewModel && crmSystemEvents;

            if (validation) {
                viewModel.switchDashboard = function (customerId) {
                    if (customerId) {
                        viewModel.$emit(crmSystemEvents.DASHBOARD_SWITCH_EVENT, customerId);
                    }
                };
            }
        },
        newCustomerHomeViewController: function (viewModel,
                                                 customerService, timeout,
                                                 stateService, redirectDetails) {
            var validation = viewModel && customerService &&
                timeout && stateService && redirectDetails;

            if (validation) {
                viewModel.saveFlag = false;

                viewModel.limits = {
                    minimum: MINIMUM_LIMIT,
                    maximum: MAXIMUM_LIMIT
                };
                viewModel.phoneExpression = PHONE_EXPRESSION;

                viewModel.customerRecord = {
                    id: customerService.generateNewCustomerId(),
                    status: true
                };

                viewModel.saveCustomerRecord = function (customerForm) {
                    if (customerForm && customerForm.$valid) {
                        customerService
                            .saveCustomer(viewModel.customerRecord)
                            .then(
                                function (data) {
                                    if (data && data.status) {
                                        viewModel.saveFlag = data.status;

                                        timeout(function () {
                                            stateService.go(redirectDetails.redirectTo);
                                        }, redirectDetails.redirectTimeout);
                                    }
                                },
                                function (error) {
                                    handleError(viewModel, error);
                                });
                    }
                };
            }
        }
    };

    module.exports = definitions;
})();