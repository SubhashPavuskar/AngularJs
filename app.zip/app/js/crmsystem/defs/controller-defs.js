(function () {
    'use strict';

    function handleError(viewModel, error) {
        if (viewModel && error) {
            viewModel.errorMessage = 'Error Occurred, Details : ' +
                JSON.stringify(error);

            throw error;
        }
    }

    var definitions = {
        crmSystemHomeViewController: function (viewModel, customerService) {
            var validation = viewModel && customerService;

            if (validation) {
                customerService.getCustomers().then(
                    function (data) {
                        if (data) {
                            viewModel.customers = data;
                        }
                    },
                    function (error) {
                        handleError(viewModel, error);
                    });
            }
        },
        crmSystemDashboardHomeViewController: function (viewModel, stateParameters, promiseService,
                                                        customerService, orderService,
                                                        ordersChartDataTransformService) {
            var validation = viewModel && stateParameters && promiseService &&
                customerService && orderService && ordersChartDataTransformService;

            if (validation) {
                var selectedCustomerId = stateParameters.customerId;

                var customerPromise = customerService.getCustomer(selectedCustomerId);
                var orderPromise = orderService.getOrders(selectedCustomerId);

                promiseService.all([customerPromise, orderPromise]).then(
                    function (results) {
                        if (results) {
                            viewModel.customer = results[0];
                            viewModel.orders = results[1];
                            viewModel.ordersChartData = ordersChartDataTransformService.transform(results[1]);
                        }
                    },
                    function (error) {
                        handleError(viewModel, error);
                    });
            }
        }
    };

    module.exports = definitions;
})();