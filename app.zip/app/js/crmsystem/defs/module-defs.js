(function () {
    'use strict';

    var definitions = {
        initializeCrmSystemModule: function (loggerService, globalViewModel) {
            var validation = loggerService && globalViewModel;

            if (validation) {
                globalViewModel.isAuthenticationRequired = true;

                loggerService.log('Crm System Module Initialized!');
            }
        }
    };

    module.exports = definitions;
})();