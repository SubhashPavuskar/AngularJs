(function () {
    'use strict';

    var states = {
        crmSystemHome: {
            name: 'crmSystemHome',
            url: '/crm-system-home',
            controller: 'crmSystemHomeViewController'
        }
    };

    var definitions = {
        configureCrmSystemRouter: function (stateProvider, templateUrls) {
            var validation = stateProvider && templateUrls;

            if (validation) {
                stateProvider.state(states.crmSystemHome.name, {
                    url: states.crmSystemHome.url,
                    templateUrl: function () {
                        return templateUrls.crmSystemHome;
                    },
                    controller: states.crmSystemHome.controller
                });
            }
        }
    };

    module.exports = definitions;
})();