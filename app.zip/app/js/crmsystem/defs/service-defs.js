(function () {
    'use strict';

    var MIN_ID = 11;
    var MAX_ID = 21;
    var DEFAULT_CHART_TYPE = 'line';

    var definitions = {
        customerService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var customerServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.customers.baseUrl + serviceUrls.customers.queryAndSave;
                var customerRestService = restService(customerServiceUrl);

                serviceDefinition = {
                    getCustomers: function () {
                        return customerRestService.query().$promise;
                    },
                    getCustomer: function (id) {
                        return customerRestService.get({
                            customerId: id
                        }).$promise;
                    },
                    saveCustomer: function (customer) {
                        if (customer) {
                            return customerRestService.save(customer).$promise;
                        }
                    },
                    generateNewCustomerId: function () {
                        var generateId = Math.floor(
                            Math.random() * (MAX_ID - MIN_ID) + MIN_ID);

                        return generateId;
                    }
                };
            }

            return serviceDefinition;
        },
        orderService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var orderServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.orders.baseUrl + serviceUrls.orders.queryAndSave;
                var orderRestService = restService(orderServiceUrl);

                serviceDefinition = {
                    getOrders: function (customerId) {
                        return orderRestService.query({
                            customerId: customerId
                        }).$promise;
                    }
                };
            }

            return serviceDefinition;
        },
        orderDataTransformerService: function () {
            var serviceDefinition = {
                transform: function (orders, chartType) {
                    chartType = chartType || DEFAULT_CHART_TYPE;

                    var ordersChartData = [];

                    if(orders) {
                        var orderIds = ['Order #'];
                        var orderAmounts = ['Order Amount'];

                        for(var index in orders) {
                            var order = orders[index];

                            if(order && order.orderId && order.amount) {
                                orderIds.push(order.orderId);
                                orderAmounts.push(order.amount);
                            }
                        }

                        ordersChartData = [orderIds, orderAmounts];
                    }

                    return ordersChartData;
                }
            };

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();

