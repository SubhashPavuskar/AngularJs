(function () {
    'use strict';

    var DELIMITER = ".";

    var definitions = {
        photoUrlFilter: function (baseUrl) {
            var filterLogic = function (bindingValue, filterParameter) {
                var photoUrl = '';

                if (bindingValue && filterParameter) {
                    photoUrl = baseUrl + "/Customer" +
                        bindingValue + DELIMITER + filterParameter;
                }

                return photoUrl;
            };

            return filterLogic;
        },
        statusSymbolFilter: function (symbols) {
            return function (bindingValue) {
                return bindingValue ? symbols.check : symbols.cross;
            };
        },
        healthStatusFilter: function() {
            return function(bindingValue, threshold) {
                var status = false;

                if(bindingValue) {
                    status = bindingValue >= threshold;
                }

                return status;
            };
        }
    };

    module.exports = definitions;
})();