(function () {
    'use strict';

    var DELIMITER = ".";

    var definitions = {
        photoUrlFilter: function (baseUrl) {
            var filterLogic = function (bindingValue, filterParameter) {
                var photoUrl = '';

                if (bindingValue && filterParameter) {
                    photoUrl = baseUrl + "/Customer" +
                        bindingValue + DELIMITER + filterParameter;
                }

                return photoUrl;
            };

            return filterLogic;
        }
    };

    module.exports = definitions;
})();