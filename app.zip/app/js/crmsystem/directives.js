(function () {
    'use strict';

    require('./config');

    var ngModuleName = 'com.gs.modules.crmsystem.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.config'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var customerViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerViewerDirective
        ];


    var customerDetailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerDetailViewerDirective
        ];

    var customerSearchPanelDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerSearchPanelDirective
        ];

    var orderViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.orderViewerDirective
        ];


    var orderChartViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.orderChartViewerDirective
        ];


    moduleObject.directive('customerViewer', customerViewerDirectiveDefinition);
    moduleObject.directive('customerDetailViewer', customerDetailViewerDirectiveDefinition);
    moduleObject.directive('customerSearchPanel', customerSearchPanelDirectiveDefinition);
    moduleObject.directive('orderViewer', orderViewerDirectiveDefinition);
    moduleObject.directive('orderChartViewer', orderChartViewerDirectiveDefinition);
})();