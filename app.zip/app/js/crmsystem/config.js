(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.crmsystem.config';
    var angular = require('angular');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    moduleObject.constant('crmSystemServiceUrls', {
        baseUrl: '/api',
        customers: {
            baseUrl: '/customers',
            queryAndSave: '/:customerId'
        },
        orders: {
            baseUrl: '/orders',
            queryAndSave: '/:customerId'
        }
    });

    moduleObject.constant('crmSystemViewTemplateUrls', {
        crmSystemHome: 'js/crmsystem/partials/views/crm-system-home.html'
    });

    moduleObject.constant('crmSystemDirTemplateUrls', {
        customerViewer: 'js/crmsystem/partials/directives/customer-viewer.html'
    });

    moduleObject.constant('photoBaseUrl', 'images/people');
})();