(function () {
    'use strict';

    require('./directives');
    require('./routes');
    require('./filters');

    var ngModuleName = 'com.gs.modules.crmsystem';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.directives',
            'com.gs.modules.crmsystem.filters',
            'com.gs.modules.crmsystem.routes'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var crmSystemInitializer =
        [
            '$log',
            '$rootScope',
            definitions.initializeCrmSystemModule
        ];

    moduleObject.run(crmSystemInitializer);
})();