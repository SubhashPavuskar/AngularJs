(function () {
    'use strict';

    require('angular-resource');
    require('./config');

    var ngModuleName = 'com.gs.modules.security.services';
    var angular = require('angular');
    var definitions = require('./defs/service-defs');

    var ngDependencies =
        [
            'ngResource',
            'com.gs.modules.security.config'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var authenticationServiceDefinition =
        [
            '$resource',
            '$window',
            'securityServiceUrl',
            'securityTokenInfo',
            definitions.authenticationService
        ];

    var authenticationStorageServiceDefinition =
        [
            '$window',
            'securityTokenInfo',
            definitions.authenticationStorageService
        ];

    moduleObject.factory('authenticationService', authenticationServiceDefinition);
    moduleObject.factory('authenticationStorageService', authenticationStorageServiceDefinition);
})();