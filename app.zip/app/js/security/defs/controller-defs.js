(function () {
    'use strict';

    var definitions = {
        loginPanelViewController: function (viewModel, globalViewModel, stateService,
                                            authenticationService,
                                            authenticationStorageService, redirectionUrl) {
            var validation = viewModel && globalViewModel && stateService &&
                authenticationService && authenticationStorageService && redirectionUrl;

            if (validation) {
                viewModel.authenticationFlag = false;

                viewModel.login = function () {
                    authenticationService
                        .authenticate(viewModel.userName, viewModel.password)
                        .then(
                            function (data) {
                                if (data && data.token) {
                                    authenticationStorageService.setAuthToken(data.token);

                                    globalViewModel.isAuthenticated = true;
                                    viewModel.authenticationFlag = true;
                                }
                            },
                            function (error) {
                                viewModel.authenticationFlag = false;
                            });
                };

                viewModel.logout = function () {
                    authenticationStorageService.unsetAuthToken();
                    viewModel.authenticationFlag = false;
                    globalViewModel.isAuthenticated = false;

                    stateService.go(redirectionUrl);
                };
            }
        }
    };

    module.exports = definitions;
})();