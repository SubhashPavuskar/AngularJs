(function () {
    'use strict';

    var BEARER = "Bearer";
    var DELIMITER = ' ';

    var definitions = {
        authorizationInterceptor: function (httpProvider) {
            if (httpProvider) {
                httpProvider.interceptors.push('authInterceptorService');
            }
        },
        authorizationInterceptorService: function (browser,
                                                   promiseService, authenticationStorageService, securityTokenInfo) {
            var interceptorDefinition = {};
            var validation = browser && promiseService &&
                authenticationStorageService && securityTokenInfo;

            if (validation) {
                interceptorDefinition = {
                    request: function (configuration) {
                        if (configuration) {
                            configuration.headers = configuration.headers || {};

                            var authenticationToken = authenticationStorageService.getAuthToken();

                            if (authenticationToken) {
                                configuration.headers.Authorization = BEARER + DELIMITER + authenticationToken;
                            }
                        }

                        return configuration;
                    },
                    responseError: function (error) {
                        promiseService.reject(error);
                    }
                };
            }

            return interceptorDefinition;
        }
    };

    module.exports = definitions;
})();