(function () {
    'use strict';

    var definitions = {
        initializeSecurityModule: function (logger,
                                            browser, globalViewModel, securityTokenInfo) {

            var validation = logger && browser && globalViewModel && securityTokenInfo;

            if (validation) {
                globalViewModel.isAuthenticated = false;

                var authenticationToken = browser.localStorage.getItem(securityTokenInfo.tokenKey);

                if (authenticationToken) {
                    browser.localStorage.removeItem(securityTokenInfo.tokenKey);
                }

                logger.info("Security Module Initialized!");
            }
        }
    };

    module.exports = definitions;
})();