(function () {
    'use strict';

    var definitions = {
        authenticationService: function (restService,
                                         browser, serviceUrl, securityTokenInfo) {
            var serviceDefinition = {};
            var validation = restService && browser && serviceUrl && securityTokenInfo;

            if (validation) {
                serviceDefinition = {
                    authenticate: function (userName, password) {
                        var authenticationRestService = restService(serviceUrl);

                        return authenticationRestService.save({
                            userName: userName,
                            password: password
                        }).$promise;
                    }
                };
            }

            return serviceDefinition;
        },
        authenticationStorageService: function (browser, securityTokenInfo) {
            var serviceDefinition = {};
            var validation = browser && securityTokenInfo;

            if (validation) {
                serviceDefinition = {
                    setAuthToken: function (token) {
                        if(token) {
                            browser.localStorage.setItem(securityTokenInfo.tokenKey, token);
                        }
                    },
                    unsetAuthToken: function () {
                        var authenticationKey = browser.localStorage.getItem(securityTokenInfo.tokenKey);

                        if (authenticationKey)
                            browser.localStorage.removeItem(securityTokenInfo.tokenKey);
                    },
                    getAuthToken: function() {
                        var authenticationKey = browser.localStorage.getItem(securityTokenInfo.tokenKey);

                        return authenticationKey;
                    }
                };
            }

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();