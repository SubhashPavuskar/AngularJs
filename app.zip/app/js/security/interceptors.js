(function () {
    'use strict';

    require('./config');
    require('./services');

    var ngModuleName = 'com.gs.modules.security.interceptors';
    var angular = require('angular');
    var definitions = require('./defs/interceptor-defs');

    var ngDependencies =
        [
            'com.gs.modules.security.config',
            'com.gs.modules.security.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var authorizationInterceptorDefinition =
        [
            '$httpProvider',
            definitions.authorizationInterceptor
        ];

    var authorizationInterceptorServiceDefinition =
        [
            '$window',
            '$q',
            'authenticationStorageService',
            'securityTokenInfo',
            definitions.authorizationInterceptorService
        ];

    moduleObject.factory('authInterceptorService', authorizationInterceptorServiceDefinition);
    moduleObject.config(authorizationInterceptorDefinition);
})();