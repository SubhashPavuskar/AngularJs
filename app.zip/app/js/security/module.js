(function () {
    'use strict';

    require('./directives');
    require('./config');
    require('./interceptors');

    var ngModuleName = 'com.gs.modules.security';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'com.gs.modules.security.config',
            'com.gs.modules.security.interceptors',
            'com.gs.modules.security.directives'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var securityModuleInitializerDefinition =
        [
            '$log',
            '$window',
            '$rootScope',
            'securityTokenInfo',
            definitions.initializeSecurityModule
        ]

    moduleObject.run(securityModuleInitializerDefinition);
})();