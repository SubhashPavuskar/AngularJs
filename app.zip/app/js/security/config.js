(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.security.config';
    var angular = require('angular');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    moduleObject.constant('securityDirTemplateUrls', {
        loginPanel: 'js/security/partials/directives/login-panel.html'
    });

    moduleObject.constant('securityTokenInfo', {
        tokenKey: 'intsolatk'
    });

    moduleObject.constant('securityServiceUrl', '/authenticate');
    moduleObject.constant('logoutRedirectionUrl', 'home');
})();