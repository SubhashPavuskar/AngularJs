(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.notifications.services';
    var angular = require('angular');
    var definitions = require('./defs/service-defs');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var notificationUrlProviderDefinition =
        [
            '$window',
            definitions.notificationUrlProvider
        ];

    var notificationServiceDefinition =
        [
            'notificationUrlProvider',
            definitions.notificationService
        ];

    moduleObject.factory('notificationUrlProvider', notificationUrlProviderDefinition);
    moduleObject.service('notificationService', notificationServiceDefinition);
})();