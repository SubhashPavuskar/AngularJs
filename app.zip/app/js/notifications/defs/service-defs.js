(function () {
    'use strict';

    var URL_DELIMITER = "//";
    var PROTOCOL_DELIMITER = ":";

    var socketClient = require('socket.io-client');

    function PushNotificationService(notificationUrlProvider) {
        var self = this;
        var registeredCallbacks = {};

        if (notificationUrlProvider) {
            var notificationUrl = notificationUrlProvider.getNotificationUrl();
            var socket = socketClient.connect(notificationUrl);

            this.registerCallback = function (eventName, callback) {
                var callbacks = registeredCallbacks[eventName];

                if (!callbacks) {
                    callbacks = [];

                    socket.on(eventName, function (message) {
                        if (message) {
                            for (var index in callbacks) {
                                var notificationCallback = callbacks[index];

                                if (notificationCallback)
                                    notificationCallback(message);
                            }
                        }
                    });
                }

                callbacks.push(callback);
            };
        }
    }

    var definitions = {
        notificationUrlProvider: function (browser) {
            var serviceDefinition = {
                getNotificationUrl: function () {
                    var notificationUrl = '';

                    if (browser) {
                        notificationUrl = browser.location.protocol + URL_DELIMITER +
                            browser.location.hostname + PROTOCOL_DELIMITER +
                            browser.location.port;
                    }

                    return notificationUrl;
                }
            };

            return serviceDefinition;
        },
        notificationService: PushNotificationService
    };

    module.exports = definitions;
})();