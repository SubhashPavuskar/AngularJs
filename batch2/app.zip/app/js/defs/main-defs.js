/**
 * Created by Ramkumar on 10/4/2016.
 */

(function () {
    'use strict';

    var angular = require('angular');

    var definitions = {
        initializeApp: function (loggerService) {
            if (loggerService) {
                loggerService.info('Application Initialized!');
            }
        },
        bootstrapApp: function (moduleName) {
            if (angular) {
                angular
                    .element(document)
                    .ready(function () {
                        angular.bootstrap(document, moduleName);
                    });
            }
        }
    };

    module.exports = definitions;
})();
