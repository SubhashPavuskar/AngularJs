(function () {
    'use strict';

    var HTTP_DIR_LIMITER = "//";
    var PROTOCOL_DELIMITER = ":";

    var socketClient = require('socket.io-client');

    function PushNotificationService(notificationUrlProvider) {
        if (notificationUrlProvider) {
            var registeredCallbacks = {};
            var notificationUrl = notificationUrlProvider.getNotificationUrl();

            var notificationSocket = socketClient.connect(notificationUrl);

            this.registerNotification = function (eventName, callback) {
                if (eventName && callback) {
                    var callbacks = registeredCallbacks[eventName];

                    if (!callbacks) {
                        callbacks = [];

                        notificationSocket.on(eventName, function (notificationMessage) {
                            if (notificationMessage) {
                                for (var index in callbacks) {
                                    var notificationCallback = callbacks[index];

                                    if (notificationCallback)
                                        notificationCallback(notificationMessage);
                                }
                            }
                        });
                    }

                    callbacks.push(callback);
                }
            };
        }
    }

    var definitions = {
        notificationUrlProvider: function (browser) {
            var serviceDefinition = {};

            if (browser) {
                serviceDefinition = {
                    getNotificationUrl: function () {
                        var notificationUrl =
                            browser.location.protocol + HTTP_DIR_LIMITER +
                            browser.location.hostname + PROTOCOL_DELIMITER +
                            browser.location.port;

                        return notificationUrl;
                    }
                };
            }

            return serviceDefinition;
        },
        notificationService: PushNotificationService
    };

    module.exports = definitions;
})();