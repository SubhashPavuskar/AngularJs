(function () {
    'use strict';

    var definitions = {
        initializeNotificationModule: function (logger) {
            if (logger) {
                logger.info('Notification Module Initialized!');
            }
        }
    };

    module.exports = definitions;
})();