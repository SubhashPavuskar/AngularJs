(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.security.config';
    var angular = require('angular');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    moduleObject.constant('securityTokenInfo', {
        tokenKey: 'intsolatk'
    });

    moduleObject.constant('securityDirTemplateUrls', {
        loginPanel: 'js/security/partials/directives/login-panel.html'
    });

    moduleObject.constant('authenticationServiceUrl', '/authenticate');
    moduleObject.constant('logoutRedirectDetails', {
        redirectTo: 'home'
    });
})();