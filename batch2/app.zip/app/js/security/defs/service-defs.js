(function () {
    'use strict';

    var definitions = {
        authenticationService: function (restService, serviceUrl) {
            var serviceDefinition = {};
            var validation = restService && serviceUrl;

            if (validation) {
                serviceDefinition = {
                    authenticate: function (userName, password) {
                        var authenticationRestService = restService(serviceUrl);

                        return authenticationRestService.save({
                            userName: userName,
                            password: password
                        }).$promise;
                    }
                };
            }

            return serviceDefinition;
        },
        authenticationStorageService: function (browser, securityTokenInfo) {
            var serviceDefinition = {};
            var validation = browser && securityTokenInfo;

            if (validation) {
                serviceDefinition = {
                    setAuthToken: function (token) {
                        if (token)
                            browser.localStorage.setItem(securityTokenInfo.tokenKey, token);
                    },
                    unsetAuthToken: function () {
                        browser.localStorage.removeItem(securityTokenInfo.tokenKey);
                    },
                    getAuthToken: function () {
                        return browser.localStorage.getItem(securityTokenInfo.tokenKey);
                    }
                };
            }

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();