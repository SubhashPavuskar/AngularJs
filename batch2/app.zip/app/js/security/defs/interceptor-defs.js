(function () {
    'use strict';

    var BEARER = "Bearer";
    var AUTHORIZATION_DELIMITER = " ";
    var HTTP_UNAUTHORIZED = 401;

    var definitions = {
        authorizationInterceptorService: function (promiseService, authenticationStorageService) {
            var serviceDefinition = {};
            var validation = promiseService && authenticationStorageService;

            if (validation) {
                serviceDefinition = {
                    request: function (configuration) {
                        var token = authenticationStorageService.getAuthToken();

                        if (configuration && token) {
                            configuration.headers = configuration.headers || {};
                            configuration.headers.Authorization = BEARER +
                                AUTHORIZATION_DELIMITER + token;
                        }

                        return configuration;
                    },
                    responseError: function (error) {
                        if (error.statusCode === HTTP_UNAUTHORIZED) {
                            // TODO: WRITE LOGIC TO REDIRECT THE USER TO LOGIN VIEW
                        }

                        return promiseService.reject(error);
                    }
                };
            }

            return serviceDefinition;
        },
        configureAuthorizationInterceptors: function (httpProvider) {
            if (httpProvider) {
                httpProvider.interceptors.push('authorizationInterceptorService');
            }
        }
    };

    module.exports = definitions;
})();