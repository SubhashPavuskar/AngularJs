(function () {
    'use strict';

    var definitions = {
        initializeSecurityModule: function (logger, globalViewModel,
                                            browser, authenticationStorageService) {
            var validation = logger && globalViewModel &&
                browser && authenticationStorageService;

            if (validation) {
                globalViewModel.isAuthenticated = false;

                authenticationStorageService.unsetAuthToken();

                logger.info('Security Module Initialized!');
            }
        }
    };

    module.exports = definitions;
})();