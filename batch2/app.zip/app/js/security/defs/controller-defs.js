(function () {
    'use strict';

    var definitions = {
        loginPanelViewerController: function (viewModel, globalViewModel, stateService,
                                              authenticationService, authenticationStorageService, redirectDetails) {
            var validation = viewModel && globalViewModel && stateService &&
                authenticationService && authenticationStorageService && redirectDetails;

            if (validation) {
                viewModel.authStatus = false;

                viewModel.login = function () {
                    authenticationService
                        .authenticate(viewModel.userName, viewModel.password)
                        .then(
                            function (result) {
                                if (result && result.token) {
                                    viewModel.authStatus = true;
                                    globalViewModel.isAuthenticated = true;
                                    authenticationStorageService.setAuthToken(result.token);
                                }
                            },
                            function (error) {
                                viewModel.error = 'Authentication Failed, Details : ' +
                                    JSON.stringify(error);

                                throw error;
                            });
                };

                viewModel.logout = function () {
                    viewModel.authStatus = false;
                    globalViewModel.isAuthenticated = false;

                    authenticationStorageService.unsetAuthToken();

                    stateService.go(redirectDetails.redirectTo);
                };
            }
        }
    };

    module.exports = definitions;
})();