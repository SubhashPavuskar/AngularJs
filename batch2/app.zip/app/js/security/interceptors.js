(function () {
    'use strict';

    require('./services')

    var ngModuleName = 'com.gs.modules.security.interceptors';
    var angular = require('angular');
    var definitions = require('./defs/interceptor-defs');

    var ngDependencies =
        [
            'com.gs.modules.security.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var authorizationInterceptorServiceDefinition =
        [
            '$q',
            'authenticationStorageService',
            definitions.authorizationInterceptorService
        ];

    var authorizationInterceptorsConfiguration =
        [
            '$httpProvider',
            definitions.configureAuthorizationInterceptors
        ];

    moduleObject.factory('authorizationInterceptorService', authorizationInterceptorServiceDefinition);
    moduleObject.config(authorizationInterceptorsConfiguration);
})();