(function () {
    'use strict';

    var c3 = require('c3');
    var definitions = {
        chartRendererController: function (viewModel) {
            if (viewModel) {
                viewModel.$watch('chartData',
                    function (newValue) {
                        if (newValue && c3) {
                            c3.generate({
                                bindto: viewModel.targetDomElement,
                                data: {
                                    columns: viewModel.chartData
                                },
                                type: viewModel.chartType
                            })
                        }
                    });
            }
        }
    };

    module.exports = definitions;
})();