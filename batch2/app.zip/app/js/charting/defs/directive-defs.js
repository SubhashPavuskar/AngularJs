(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        chartRendererDirective: function () {
            var templateUrl = null;
            var scope = {
                targetDomElement: '@',
                chartData: '=',
                chartType: '@'
            };
            var controller = 'chartRendererController';

            return directiveUtils.createDirective(templateUrl, scope, controller);
        }
    };

    module.exports = definitions;
})();