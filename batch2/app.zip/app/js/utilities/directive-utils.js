(function () {
    'use strict';

    var definitions = {
        createDirective: function (url, scope, controller) {
            var definition = {
                restrict: 'EA'
            };

            if (url) {
                definition.templateUrl = function () {
                    return url;
                };
            }

            if (scope) {
                definition.scope = scope;
            }

            if (controller) {
                definition.controller = controller;
            }

            return definition;
        }
    };

    module.exports = definitions;
})();