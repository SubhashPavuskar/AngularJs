(function () {
    'use strict';

    var DEFAULT_CHART_TYPE = "line";
    var MIN_QUOTE_VALUE = 100;
    var MAX_QUOTE_VALUE = 1000;
    var MIN_ID = 11;
    var MAX_ID = 21;

    var definitions = {
        customerService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var customerServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.customers.baseUrl + serviceUrls.customers.queryAndSave;
                var customerRestService = restService(customerServiceUrl);

                serviceDefinition = {
                    getCustomers: function () {
                        return customerRestService.query().$promise;
                    },
                    getCustomerDetail: function (id) {
                        return customerRestService.get({
                            customerId: id
                        }).$promise;
                    },
                    saveCustomerDetail: function (detail) {
                        return customerRestService.save(detail).$promise;
                    },
                    generateNewCustomerId: function () {
                        var generatedId = Math.floor(
                            Math.random() * (MAX_ID - MIN_ID) + MIN_ID);

                        return generatedId;
                    }
                };
            }

            return serviceDefinition;
        },
        orderService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var orderServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.orders.baseUrl + serviceUrls.orders.queryAndSave;
                var orderRestService = restService(orderServiceUrl);

                serviceDefinition = {
                    getOrders: function (customerId) {
                        return orderRestService.query({
                            customerId: customerId
                        }).$promise;
                    }
                };
            }

            return serviceDefinition;
        },
        orderDataTransformationService: function () {
            var serviceDefinition = {
                transform: function (data, chartType) {
                    var ordersChartData = [];

                    chartType = chartType || DEFAULT_CHART_TYPE;

                    if (data) {
                        var orderIds = ['Order #'];
                        var orderAmounts = ['Order Amount'];

                        for (var index in data) {
                            var order = data[index];

                            if (order && order.orderId && order.amount) {
                                orderIds.push(order.orderId);
                                orderAmounts.push(order.amount);
                            }
                        }

                        ordersChartData = [orderIds, orderAmounts];
                    }

                    return ordersChartData;
                }
            };

            return serviceDefinition;
        },
        stockQuoteService: function () {
            var serviceDefinition = {
                getStockQuote: function (customerId) {
                    var quotation = 0;

                    if (customerId) {
                        quotation = Math.floor(Math.random() *
                            (MAX_QUOTE_VALUE - MIN_QUOTE_VALUE) + MIN_QUOTE_VALUE);
                    }

                    return quotation;
                }
            };

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();