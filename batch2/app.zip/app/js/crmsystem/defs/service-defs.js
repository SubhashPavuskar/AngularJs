(function () {
    'use strict';

    var definitions = {
        customerService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var customerServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.customers.baseUrl + serviceUrls.customers.queryAndSave;
                var customerRestService = restService(customerServiceUrl);

                serviceDefinition = {
                    getCustomers: function () {
                        return customerRestService.query().$promise;
                    },
                    getCustomerDetail: function (id) {
                        return customerRestService.get({
                            customerId: id
                        }).$promise;
                    },
                    saveCustomerDetail: function (detail) {
                        return customerRestService.save(detail).$promise;
                    }
                };
            }

            return serviceDefinition;
        },
        orderService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var orderServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.orders.baseUrl + serviceUrls.orders.queryAndSave;
                var orderRestService = restService(orderServiceUrl);

                serviceDefinition = {
                    getOrders: function (customerId) {
                        return orderRestService.query({
                            customerId: customerId
                        }).$promise;
                    }
                };
            }

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();