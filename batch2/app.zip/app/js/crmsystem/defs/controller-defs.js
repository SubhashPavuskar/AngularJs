(function () {
    'use strict';

    var UPPER_LIMIT = 6;
    var LOWER_LIMIT = 0;
    var VALUE_UNIT = '₹ ';
    var GAUGE_PRECISION = 2;
    var RANGES = [
        {
            min: 0,
            max: 1.5,
            color: '#DEDEDE'
        },
        {
            min: 1.5,
            max: 2.5,
            color: '#8DCA2F'
        },
        {
            min: 2.5,
            max: 3.5,
            color: '#FDC702'
        },
        {
            min: 3.5,
            max: 4.5,
            color: '#FF7700'
        },
        {
            min: 4.5,
            max: 6.0,
            color: '#C50200'
        }
    ];

    function handleError(viewModel, error) {
        if (viewModel && error) {
            viewModel.errorMessage = 'Error Occurred, Details : ' +
                JSON.stringify(error);

            throw error;
        }
    }

    var definitions = {
        crmSystemHomeViewController: function (viewModel, customerService) {
            var validation = viewModel && customerService;

            if (validation) {
                customerService.getCustomers().then(
                    function (data) {
                        if (data) {
                            viewModel.customers = data;
                        }
                    },
                    function (error) {
                        handleError(viewModel, error);
                    });
            }
        },
        crmSystemDashboardHomeViewController: function (viewModel, promiseService,
                                                        stateParameters, customerService,
                                                        orderService, orderDataTransformationService) {
            var validation = viewModel && stateParameters &&
                promiseService && customerService && orderService && orderDataTransformationService;

            if (validation) {
                var selectedCustomerId = stateParameters.customerId;

                var customerPromise = customerService.getCustomerDetail(selectedCustomerId);
                var orderPromise = orderService.getOrders(selectedCustomerId);

                promiseService.all([customerPromise, orderPromise]).then(
                    function (results) {
                        if (results) {
                            viewModel.customer = results[0];
                            viewModel.orders = results[1];
                            viewModel.ordersChartData = orderDataTransformationService.transform(results[1]);
                        }
                    },
                    function (error) {
                        handleError(viewModel, error);
                    });
            }
        },
        stockViewerController: function (viewModel, interval, browser, stockQuoteService) {
            var validation = viewModel && interval && browser && stockQuoteService;
            var initializeQuotation = function () {
                var quotation = stockQuoteService.getStockQuote(viewModel.customerId);

                viewModel.quotation = quotation;
                viewModel.stockQuoteHistory.unshift({
                    time: new Date(),
                    quotation: quotation
                });

                if (viewModel.gaugeData) {
                    viewModel.gaugeData.value = Math.floor(quotation % UPPER_LIMIT);
                }
            };

            var timerObject = null;

            if (validation) {
                viewModel.gaugeData = {
                    upperLimit: UPPER_LIMIT,
                    lowerLimit: LOWER_LIMIT,
                    valueUnit: VALUE_UNIT,
                    precision: GAUGE_PRECISION,
                    ranges: RANGES,
                    value: 0
                };

                viewModel.stockQuoteHistory = [];

                viewModel.$watch('refreshInterval', function (newValue) {
                    if (newValue) {
                        if (timerObject) {
                            browser.clearInterval(timerObject.$$intervalId);
                        }

                        timerObject = interval(
                            initializeQuotation, viewModel.refreshInterval);
                    }
                });
            }
        }
    };

    module.exports = definitions;
})();
