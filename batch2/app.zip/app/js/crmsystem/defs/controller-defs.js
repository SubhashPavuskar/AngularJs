(function () {
    'use strict';

    function handleError(viewModel, error) {
        if (viewModel && error) {
            viewModel.errorMessage = 'Error Occurred, Details : ' +
                JSON.stringify(error);

            throw error;
        }
    }

    var definitions = {
        crmSystemHomeViewController: function (viewModel, customerService) {
            var validation = viewModel && customerService;

            if (validation) {
                customerService.getCustomers().then(
                    function (data) {
                        if (data) {
                            viewModel.customers = data;
                        }
                    },
                    function (error) {
                        handleError(viewModel, error);
                    });
            }
        }
    };

    module.exports = definitions;
})();
