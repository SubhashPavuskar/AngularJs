(function () {
    'use strict';

    var states = {
        crmSystemHome: {
            name: 'crmSystemHome',
            url: '/crm-system-home',
            controller: 'crmSystemHomeViewController'
        },
        crmSystemDashboardHome: {
            name: 'crmSystemDashboardHome',
            url: '/crm-system-dashboard-home/:customerId',
            controller: 'crmSystemDashboardHomeViewController'
        },
        newCustomerHome: {
            name: 'newCustomerHome',
            url: '/new-customer-home',
            controller: 'newCustomerHomeViewController'
        }
    };

    var definitions = {
        configureCrmSystemRouter: function (stateProvider, templateUrls) {
            var validation = stateProvider && templateUrls;

            if (validation) {
                stateProvider.state(states.crmSystemHome.name, {
                    url: states.crmSystemHome.url,
                    templateUrl: function () {
                        return templateUrls.crmSystemHome;
                    },
                    controller: states.crmSystemHome.controller
                });

                stateProvider.state(states.crmSystemDashboardHome.name, {
                    url: states.crmSystemDashboardHome.url,
                    templateUrl: function () {
                        return templateUrls.crmSystemDashboardHome;
                    },
                    controller: states.crmSystemDashboardHome.controller
                });

                stateProvider.state(states.newCustomerHome.name, {
                    url: states.newCustomerHome.url,
                    templateUrl: function () {
                        return templateUrls.newCustomerHome;
                    },
                    controller: states.newCustomerHome.controller
                });
            }
        }
    };

    module.exports = definitions;
})();
