(function () {
    'use strict';

    var DELIMITER = '.';
    var DEFAULT_FORMAT = "JPG";

    var definitions = {
        photoUrlFilter: function (photoBaseUrl) {
            return function (bindingValue, filterParameter) {
                var photoUrl = '';

                filterParameter = filterParameter || DEFAULT_FORMAT;

                if (bindingValue && filterParameter) {
                    photoUrl = photoBaseUrl + '/Customer' + bindingValue
                        + DELIMITER + filterParameter;
                }

                return photoUrl;
            }
        },
        statusSymbolFilter: function (symbols) {
            return function (bindingValue) {
                return bindingValue ? symbols.check : symbols.cross;
            }
        },
        healthStatusFilter: function () {
            return function (bindingValue, threshold) {
                var status = false;

                if (bindingValue) {
                    status = bindingValue >= threshold;
                }

                return status;
            }
        }
    };

    module.exports = definitions;
})();
