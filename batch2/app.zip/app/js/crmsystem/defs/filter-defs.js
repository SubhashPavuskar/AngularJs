(function () {
    'use strict';

    var definitions = {
        photoUrlFilter: function (photoBaseUrl) {
            return function (bindingValue) {
                var photoUrl = '';

                if (bindingValue) {
                    photoUrl = photoBaseUrl + '/Customer' + bindingValue + '.jpg';
                }

                return photoUrl;
            }
        }
    };

    module.exports = definitions;
})();
