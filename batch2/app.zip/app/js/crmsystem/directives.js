(function () {
    'use strict';

    require('./config');

    var ngModuleName = 'com.gs.modules.crmsystem.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.config'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var customerViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerViewerDirective
        ];

    var customerDetailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerDetailViewerDirective
        ];

    var customerSearchPanelDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerSearchPanelDirective
        ];

    var orderViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.orderViewerDirective
        ];

    var stockViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.stockViewerDirective
        ];

    var stockQuoteHistoryViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.stockQuoteHistoryViewerDirective
        ];

    var dashboardSwitchPanelViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.dashboardSwitchPanelViewerDirective
        ];

    var creditLimitValidationDirectiveDefinition =
        [
            definitions.creditLimitValidationDirective
        ];

    moduleObject.directive('gsCustomerViewer', customerViewerDirectiveDefinition);
    moduleObject.directive('gsCustomerDetailViewer', customerDetailViewerDirectiveDefinition);
    moduleObject.directive('gsCustomerSearchPanel', customerSearchPanelDirectiveDefinition);
    moduleObject.directive('gsOrderViewer', orderViewerDirectiveDefinition);
    moduleObject.directive('gsStockViewer', stockViewerDirectiveDefinition);
    moduleObject.directive('gsStockQuoteHistoryViewer', stockQuoteHistoryViewerDirectiveDefinition);
    moduleObject.directive('gsDashboardSwitchPanelViewer', dashboardSwitchPanelViewerDirectiveDefinition);
    moduleObject.directive('gsCreditLimitValidation', creditLimitValidationDirectiveDefinition);
})();