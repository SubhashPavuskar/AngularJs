(function () {
    'use strict';

    require('ngRadialGauge');
    require('../notifications/module');
    require('../charting/module');
    require('./routes');
    require('./filters');
    require('./directives');

    var ngModuleName = 'com.gs.modules.crmsystem';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'ngRadialGauge',
            'com.gs.modules.notifications',
            'com.gs.modules.charting',
            'com.gs.modules.crmsystem.filters',
            'com.gs.modules.crmsystem.directives',
            'com.gs.modules.crmsystem.routes'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var crmSystemModuleInitializer =
        [
            '$log',
            '$rootScope',
            definitions.initializeCrmSystemModule
        ];

    moduleObject.run(crmSystemModuleInitializer);
})();