(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.crmsystem.config';
    var angular = require('angular');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    moduleObject.constant('crmSystemDirTemplateUrls', {
        customerThumbnailViewer: 'js/crmsystem/partials/directives/customer-thumbnail-viewer.html',
        customerDetailViewer: 'js/crmsystem/partials/directives/customer-detail-viewer.html',
        customerSearchPanel: 'js/crmsystem/partials/directives/customer-search-panel.html',
        orderViewer: 'js/crmsystem/partials/directives/order-viewer.html',
        stockViewer: 'js/crmsystem/partials/directives/stock-viewer.html',
        stockQuoteHistoryViewer: 'js/crmsystem/partials/directives/stock-quote-history-viewer.html',
        dashboardSwitchPanelViewer: 'js/crmsystem/partials/directives/dashboard-switch-panel-viewer.html'
    });

    moduleObject.constant('crmSystemViewTemplateUrls', {
        crmSystemHome: 'js/crmsystem/partials/views/crm-system-home.html',
        crmSystemDashboardHome: 'js/crmsystem/partials/views/crm-system-dashboard-home.html',
        newCustomerHome: 'js/crmsystem/partials/views/new-customer-home.html'
    });

    moduleObject.constant('crmSystemServiceUrls', {
        baseUrl: '/api',
        customers: {
            baseUrl: '/customers',
            queryAndSave: '/:customerId'
        },
        orders: {
            baseUrl: '/orders',
            queryAndSave: '/:customerId'
        }
    });

    moduleObject.constant('photoBaseUrl', 'images/people');
    moduleObject.constant('symbols', {
        check: '\u2713',
        cross: '\u2718'
    });

    moduleObject.constant('crmSystemEvents', {
        DASHBOARD_SWITCH_EVENT: 'dashboardSwitchEvent'
    });

    moduleObject.constant('newCustomerRedirectionDetails', {
        redirectTo: 'crmSystemHome',
        redirectTimeout: 5000
    });
})();