/**
 * Created by Ramkumar on 10/4/2016.
 */
(function () {
    'use strict';

    window.d3 = require('d3');

    require('jquery-browserify');
    require('bootstrap');

    require('./common/module');
    require('./building-blocks/module');
    require('./crmsystem/module');

    var ngModuleName = 'com.gs.app';
    var angular = require('angular');
    var definitions = require('./defs/main-defs');
    var ngDependencies =
        [
            'com.gs.modules.building-blocks',
            'com.gs.modules.common',
            'com.gs.modules.crmsystem'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var appInitializer =
        [
            '$log',
            definitions.initializeApp
        ];

    var configureSeoSettingsDefinition =
        [
            '$locationProvider',
            definitions.configureSeoSettings
        ];

    moduleObject.run(appInitializer);
    moduleObject.config(configureSeoSettingsDefinition);

    definitions.bootstrapApp([ngModuleName]);
})();