(function () {
    'use strict';

    require('../security/module');
    require('./directives');
    require('./routes');
    require('./decorators');

    var ngModuleName = 'com.gs.modules.common';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'com.gs.modules.security',
            'com.gs.modules.common.directives',
            'com.gs.modules.common.routes',
            'com.gs.modules.common.decorators'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var moduleInitializer =
        [
            '$log',
            '$rootScope',
            definitions.initializeModule
        ];

    moduleObject.run(moduleInitializer);
})();