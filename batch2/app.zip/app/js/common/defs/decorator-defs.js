(function () {
    'use strict';

    var CACHE_CONTAINER = 'subHeadingsCacheContainer';
    var CACHE_ITEM_KEY = 'subHeadingsCache';

    function decorateSubHeadingService(delegateService,
                                       promiseService, cacheFactory, loggerService) {
        var validation = delegateService && promiseService &&
            cacheFactory && loggerService;

        if (validation) {
            var realService = delegateService.getSubHeadings;

            delegateService.getSubHeadings = function () {
                var deferred = promiseService.defer();

                var cacheContainer = cacheFactory(CACHE_CONTAINER);
                var cache = cacheContainer.get(CACHE_ITEM_KEY);

                if (cache) {
                    loggerService.info('Cache Found!');

                    deferred.resolve(cache);
                } else {
                    loggerService.info('Cache Not Found!');

                    realService().then(
                        function (data) {
                            if (data) {
                                cacheContainer.put(CACHE_ITEM_KEY, data);

                                deferred.resolve(data);
                            }
                        },
                        function (error) {
                            deferred.reject(error);
                        });
                }

                return deferred.promise;
            };
        }

        return delegateService;
    }

    var definitions = {
        configureDecorators: function (provideService) {
            if (provideService) {
                var subHeadingDecoratorDefinition =
                    [
                        '$delegate',
                        '$q',
                        '$cacheFactory',
                        '$log',
                        decorateSubHeadingService
                    ];

                provideService.decorator('subHeadingService', subHeadingDecoratorDefinition);
            }
        }
    };

    module.exports = definitions;
})();