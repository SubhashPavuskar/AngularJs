(function () {
    'use strict';

    var definitions = {
        subHeadingService: function (restService, serviceUrl) {
            var service = {};
            var validation = restService && serviceUrl;

            if (validation) {
                var subHeadingRestService = restService(serviceUrl);

                service = {
                    getSubHeadings: function () {
                        return subHeadingRestService.query().$promise;
                    }
                };
            }

            return service;
        }
    };

    module.exports = definitions;
})();