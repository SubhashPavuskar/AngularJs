(function () {
    'use strict';

    require('./config');
    require('./controllers');

    var ngModuleName = 'com.gs.modules.common.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.common.config',
            'com.gs.modules.common.controllers'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var headerDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.headerDirective
        ];

    var navigationDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.navigationDirective
        ];

    var footerDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.footerDirective
        ];

    var subHeadingViewerDirectiveDefinition =
        [
            'commonDirTemplateUrls',
            definitions.subHeadingViewerDirective
        ];

    moduleObject.directive('gsCommonHeader', headerDirectiveDefinition);
    moduleObject.directive('gsCommonNavigation', navigationDirectiveDefinition);
    moduleObject.directive('gsCommonFooter', footerDirectiveDefinition);
    moduleObject.directive('gsSubHeadingViewer', subHeadingViewerDirectiveDefinition);
})();