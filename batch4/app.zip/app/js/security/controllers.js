(function () {
    'use strict';

    require('./services');

    var ngModuleName = 'com.gs.modules.security.controllers';
    var angular = require('angular');
    var definitions = require('./defs/controller-defs');

    var ngDependencies =
        [
            'com.gs.modules.security.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var loginPanelControllerDefinition =
        [
            '$scope',
            '$rootScope',
            '$state',
            'authenticationService',
            'authenticationStorageService',
            definitions.loginPanelController
        ];

    moduleObject.controller('loginPanelController', loginPanelControllerDefinition);
})();