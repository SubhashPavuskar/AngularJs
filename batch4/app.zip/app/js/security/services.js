(function () {
    'use strict';

    var angular = require('angular');

    require('angular-resource');
    require('./config');

    var ngModuleName = 'com.gs.modules.security.services';
    var definitions = require('./defs/service-defs');

    var ngDependencies =
        [
            'ngResource',
            'com.gs.modules.security.config'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var authenticationStorageServiceDefinition =
        [
            '$window',
            'authTokenInfo',
            definitions.authenticationStorageService
        ];

    var authenticationServiceDefinition =
        [
            '$resource',
            'authServiceUrl',
            definitions.authenticationService
        ];

    moduleObject.factory('authenticationStorageService', authenticationStorageServiceDefinition);
    moduleObject.factory('authenticationService', authenticationServiceDefinition);
})();