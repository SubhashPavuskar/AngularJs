(function () {
    'use strict';

    var definitions = {
        initializeSecurityModule: function (globalViewModel, logger, authStorageService) {
            var validation = globalViewModel && logger && authStorageService;

            if (validation) {
                globalViewModel.isAuthenticated = false;

                authStorageService.unsetAuthToken();

                logger.info('Security Module Initialized!');
            }
        }
    };

    module.exports = definitions;
})();