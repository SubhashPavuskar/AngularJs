(function () {
    'use strict';

    var HTTP_AUTHORIZATION_PREFIX = "Bearer";
    var HTTP_AUTHORIZATION_DELIMITER = ' ';

    var definitions = {
        configureHttpInterceptors: function (httpProvider) {
            if (httpProvider) {
                httpProvider.interceptors.push('authorizationInterceptorService');
            }
        },
        authorizationInterceptorService: function (authenticationStorageService) {
            var serviceDefinition = {};

            if (authenticationStorageService) {
                serviceDefinition = {
                    request: function (configuration) {
                        configuration.headers = configuration.headers || {};

                        var authToken = authenticationStorageService.getAuthToken();

                        if (authToken) {
                            configuration.headers.Authorization =
                                HTTP_AUTHORIZATION_PREFIX +
                                HTTP_AUTHORIZATION_DELIMITER + authToken;
                        }

                        return configuration;
                    }
                };
            }

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();