(function () {
    'use strict';

    var viewModelErrorUtils = require('../../utilities/viewmodel-error-utils');

    var HOME_STATE = "home";

    var definitions = {
        loginPanelController: function (viewModel, globalViewModel, stateService,
                                        authenticationService, authenticationStorageService) {
            var validation = viewModel && globalViewModel && stateService &&
                authenticationService && authenticationStorageService;

            function toggleAuthStatus(status) {
                viewModel.authStatus = status;
                globalViewModel.isAuthenticated = status;
            }

            if (validation) {
                toggleAuthStatus(false);

                viewModel.login = function () {
                    authenticationService.authenticate(viewModel.userName, viewModel.password)
                        .then(
                            function (result) {
                                if (result && result.token) {
                                    authenticationStorageService.setAuthToken(result.token);
                                    toggleAuthStatus(true);
                                }
                            },
                            function (error) {
                                viewModelErrorUtils.handleError(viewModel, error);
                            });
                };

                viewModel.logout = function () {
                    toggleAuthStatus(false);
                    authenticationStorageService.unsetAuthToken();

                    stateService.go(HOME_STATE);
                };
            }
        }
    };

    module.exports = definitions;
})();