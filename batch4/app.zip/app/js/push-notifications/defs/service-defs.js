(function () {
    'use strict';

    var PROTOCOL_DELIMITER = '//';
    var PORT_DELIMITER = ':';

    var socketIOClient = require('socket.io-client');

    function GSPushNotificationService(notificationUrlProvider) {
        var registeredCallbacks = {};

        if (notificationUrlProvider) {
            var notificationUrl = notificationUrlProvider.getNotificationUrl();

            this.registerCallback = function (eventName, callback) {
                var eventCallbacks = registeredCallbacks[eventName];

                if (!eventCallbacks) {
                    registeredCallbacks[eventName] = [];
                    eventCallbacks = registeredCallbacks [eventName];

                    var socketClient = socketIOClient.connect(notificationUrl);

                    socketClient.on(eventName,
                        function (notificationData) {
                            for (var index in eventCallbacks) {
                                var callbackItem = eventCallbacks[index];

                                if (callbackItem) {
                                    callbackItem(notificationData);
                                }
                            }
                        });
                }

                eventCallbacks.push(callback);
            };
        }
    }

    var definitions = {
        notificationUrlProviderService: function (browser) {
            var serviceDefinition = {};

            if (browser) {
                serviceDefinition = {
                    getNotificationUrl: function () {
                        var url = browser.location.protocol + PROTOCOL_DELIMITER +
                            browser.location.hostname + PORT_DELIMITER +
                            browser.location.port;

                        return url;
                    }
                };
            }

            return serviceDefinition;
        },
        pushNotificationService: GSPushNotificationService
    };

    module.exports = definitions;
})();