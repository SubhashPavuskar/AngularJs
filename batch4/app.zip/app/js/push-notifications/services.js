(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.push-notifications.services';
    var angular = require('angular');
    var definitions = require('./defs/service-defs');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var notificationServiceUrlProviderDefinition =
        [
            '$window',
            definitions.notificationUrlProviderService
        ];

    var pushNotificationServiceDefinition =
        [
            'notificationUrlProviderService',
            definitions.pushNotificationService
        ];

    moduleObject.factory('notificationUrlProviderService', notificationServiceUrlProviderDefinition);
    moduleObject.service('pushNotificationService', pushNotificationServiceDefinition);
})();