(function () {
    'use strict';

    require('./services');

    var ngModuleName = 'com.gs.modules.common.controllers';
    var angular = require('angular');
    var definitions = require('./defs/controller-defs');

    var ngDependencies =
        [
            'com.gs.modules.common.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var homeViewControllerDefinition =
        [
            '$scope',
            'subHeadingService',
            definitions.homeViewController
        ];

    var aboutViewControllerDefinition =
        [
            '$scope',
            definitions.aboutViewController
        ];

    var navigationControllerDefinition =
        [
            '$scope',
            '$rootScope',
            definitions.navigationController
        ];

    moduleObject.controller('homeViewController', homeViewControllerDefinition);
    moduleObject.controller('aboutViewController', aboutViewControllerDefinition);
    moduleObject.controller('navigationController', navigationControllerDefinition);

})();