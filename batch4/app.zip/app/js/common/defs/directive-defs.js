(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        headerDirective: function (templateUrls) {
            var scope = {
                headerTitle: '@'
            };

            return directiveUtils.createDirective(templateUrls.header, scope);
        },
        navigationDirective: function (templateUrls) {
            return directiveUtils.createDirective(templateUrls.navigation);
        },
        subHeadingViewerDirective: function (templateUrls) {
            var scope = {
                headingTitle: '=',
                headingDescription: '='
            };

            return directiveUtils.createDirective(templateUrls.subHeadingViewer, scope);
        }
    };

    module.exports = definitions;
})();