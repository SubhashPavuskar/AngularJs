(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        headerDirective: function (templateUrls) {
            var scope = {
                headerTitle: '@'
            };

            return directiveUtils.createDirective(templateUrls.header, scope);
        },
        navigationDirective: function (templateUrls) {
            var scope = null;
            var controller = 'navigationController';

            return directiveUtils.createDirective(templateUrls.navigation, scope, controller);
        },
        subHeadingViewerDirective: function (templateUrls) {
            var scope = {
                headingTitle: '=',
                headingDescription: '='
            };

            return directiveUtils.createDirective(templateUrls.subHeadingViewer, scope);
        }
    };

    module.exports = definitions;
})();