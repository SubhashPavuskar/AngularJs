(function () {
    'use strict';

    require('jquery-browserify');
    require('bootstrap');
    require('./building-blocks/module');
    require('./common/module');
    require('./crmsystem/module');

    var ngModuleName = 'com.gs.app';
    var angular = require('angular');
    var definitions = require('./defs/main-defs');

    var ngDependencies =
        [
            'com.gs.modules.building-blocks',
            'com.gs.modules.common',
            'com.gs.modules.crmsystem'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var appInitializerDefinition =
        [
            '$log',
            '$rootScope',
            definitions.initializeApp
        ];

    var seoSettingsConfigurationDefinition =
        [
            '$locationProvider',
            definitions.configureSEOSettings
        ];

    moduleObject.config(seoSettingsConfigurationDefinition);
    moduleObject.run(appInitializerDefinition);

    definitions.bootstrapApp(ngModuleName);
})();