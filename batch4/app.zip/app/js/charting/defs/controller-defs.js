(function () {
    'use strict';

    var definitions = {
        chartRendererController: function (viewModel) {
            var c3 = require('c3');
            var validation = c3 && viewModel;

            if (validation) {
                viewModel.$watch('chartData',
                    function (newValue) {
                        if (newValue) {
                            c3.generate({
                                bindto: viewModel.targetDomElement,
                                data: {
                                    type: viewModel.chartType,
                                    columns: viewModel.chartData
                                }
                            });
                        }
                    });
            }
        }
    };

    module.exports = definitions;
})();