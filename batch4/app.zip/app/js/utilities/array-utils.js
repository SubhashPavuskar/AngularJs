(function () {
    'use strict';

    Array.prototype.isExist = function (item) {
        var existStatus = false;

        if (item) {
            for (var index in this) {
                if (this[index] === item) {
                    existStatus = true;
                    break;
                }
            }
        }

        return existStatus;
    };
})();