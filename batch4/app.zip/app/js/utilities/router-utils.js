/**
 * Created by Ramkumar on 11/14/2016.
 */
(function () {
    'use strict';

    var definitions = {
        configureRouter: function(stateProvider, states, templateUrls) {
            for (var state in states) {
                (function () {
                    var currentState = state;

                    stateProvider.state(states[currentState].name, {
                        url: states[currentState].url,
                        templateUrl: function () {
                            return templateUrls[currentState];
                        },
                        controller: states[currentState].controller
                    });
                })();
            }
        }
    };

    module.exports = definitions;
})();