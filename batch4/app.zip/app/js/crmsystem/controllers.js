(function () {
    'use strict';

    require('../push-notifications/module');
    require('./services');

    var ngModuleName = 'com.gs.modules.crmsystem.controllers';
    var angular = require('angular');
    var definitions = require('./defs/controller-defs');

    var ngDependencies =
        [
            'com.gs.modules.push-notifications',
            'com.gs.modules.crmsystem.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var crmSystemHomeViewControllerDefinition =
        [
            '$scope',
            'customerService',
            'pushNotificationService',
            definitions.crmSystemHomeViewController
        ];

    var crmSystemDashboardHomeViewControllerDefinition =
        [
            '$scope',
            '$q',
            '$stateParams',
            '$state',
            'customerService',
            'orderService',
            'orderChartDataTransformationService',
            'crmSystemEvents',
            definitions.crmSystemDashboardHomeViewController
        ];

    var stockViewerControllerDefinition =
        [
            '$scope',
            '$interval',
            '$window',
            'stockQuoteService',
            definitions.stockViewerController
        ];

    var dashboardSwitchPanelControllerDefinition =
        [
            '$scope',
            'crmSystemEvents',
            definitions.dashboardSwitchPanelController
        ];

    var newCustomerHomeViewControllerDefinition =
        [
            '$scope',
            'customerService',
            definitions.newCustomerHomeViewController
        ];

    moduleObject.controller('crmSystemHomeViewController', crmSystemHomeViewControllerDefinition);
    moduleObject.controller('crmSystemDashboardHomeViewController', crmSystemDashboardHomeViewControllerDefinition);
    moduleObject.controller('stockViewerController', stockViewerControllerDefinition);
    moduleObject.controller('dashboardSwitchPanelController', dashboardSwitchPanelControllerDefinition);
    moduleObject.controller('newCustomerHomeViewController', newCustomerHomeViewControllerDefinition);
})();