(function () {
    'use strict';

    var viewModelErrorUtils = require('../../utilities/viewmodel-error-utils');

    var LOWER_LIMIT = 0;
    var UPPER_LIMIT = 6;
    var VALUE_UNIT = '₹ ';
    var PRECISION = 2;
    var COLOR_RANGES = [
        {
            min: 0,
            max: 1.5,
            color: '#DEDEDE'
        },
        {
            min: 1.5,
            max: 2.5,
            color: '#8DCA2F'
        },
        {
            min: 2.5,
            max: 3.5,
            color: '#FDC702'
        },
        {
            min: 3.5,
            max: 4.5,
            color: '#FF7700'
        },
        {
            min: 4.5,
            max: 6.0,
            color: '#C50200'
        }
    ];

    var DASHBOARD_STATE = "crmSystemDashboardHome";
    var MINIMUM_CREDIT = 1000;
    var MAXIMUM_CREDIT = 50000;
    var PUSH_NOTIFICATION_EVENT = "newCustomerRecord";

    var definitions = {
        crmSystemHomeViewController: function (viewModel, customerService, pushNotificationService) {
            var validation = viewModel && customerService && pushNotificationService;

            if (validation) {
                pushNotificationService.registerCallback(PUSH_NOTIFICATION_EVENT,
                    function (notificationData) {
                        var validation = notificationData &&
                            viewModel && viewModel.customers;

                        if (validation) {
                            viewModel.$apply(
                                function () {
                                    viewModel.customers.push(notificationData);
                                });

                        }
                    });

                customerService.getAllCustomers()
                    .then(
                        function (data) {
                            if (data) {
                                viewModel.customers = data;
                            }
                        },
                        function (error) {
                            viewModelErrorUtils.handleError(viewModel, error);
                        });
            }
        },
        crmSystemDashboardHomeViewController: function (viewModel,
                                                        promiseService, stateParameters, stateService,
                                                        customerService, orderService,
                                                        transformationService, crmSystemEvents) {
            var validation = viewModel && promiseService && stateService &&
                stateParameters && customerService && orderService &&
                transformationService && crmSystemEvents;

            if (validation) {

                viewModel.$on(crmSystemEvents.DASHBOARD_SWITCH_EVENT,
                    function (eventInfo, eventData) {
                        var selectedCustomerId = eventData;

                        stateService.go(DASHBOARD_STATE, {
                            customerId: selectedCustomerId
                        });
                    });

                var selectedCustomerId = stateParameters.customerId;

                if (selectedCustomerId) {
                    var customerPromise = customerService.getCustomerDetail(selectedCustomerId);
                    var ordersPromise = orderService.getOrdersByCustomerId(selectedCustomerId);

                    promiseService.all([customerPromise, ordersPromise])
                        .then(
                            function (results) {
                                if (results) {
                                    viewModel.customer = results[0];
                                    viewModel.orders = results[1];
                                    viewModel.ordersChartData = transformationService.transform(results[1]);
                                }
                            },
                            function (error) {
                                viewModelErrorUtils.handleError(viewModel, error);
                            });
                }
            }
        },
        stockViewerController: function (viewModel, timer, browser, stockQuoteService) {
            var validation = viewModel && timer && browser && stockQuoteService;

            if (validation) {
                var timerObject = null;
                var initializeQuotation = function () {
                    var quotation = stockQuoteService.getStockQuote(viewModel.customerDetail.name);

                    viewModel.quotation = quotation;
                    viewModel.stockQuoteHistory.unshift({
                        time: new Date(),
                        quotation: quotation
                    });

                    if (viewModel.gaugeData) {
                        viewModel.gaugeData.value = Math.floor(quotation % UPPER_LIMIT);
                    }
                };

                viewModel.gaugeData = {
                    value: 0,
                    lowerLimit: LOWER_LIMIT,
                    upperLimit: UPPER_LIMIT,
                    precision: PRECISION,
                    valueUnit: VALUE_UNIT,
                    ranges: COLOR_RANGES
                };
                viewModel.stockQuoteHistory = [];

                viewModel.$watch('refreshInterval',
                    function (newValue) {
                        if (newValue) {
                            if (timerObject) {
                                browser.clearInterval(timerObject.$$intervalId);
                            }

                            timerObject = timer(initializeQuotation, viewModel.refreshInterval);
                        }
                    });
            }
        },
        dashboardSwitchPanelController: function (viewModel, crmSystemEvents) {
            var validation = viewModel && crmSystemEvents;

            if (validation) {
                viewModel.switchDashboard = function (customerId) {
                    if (customerId) {
                        viewModel.$emit(crmSystemEvents.DASHBOARD_SWITCH_EVENT, customerId);
                    }
                };
            }
        },
        newCustomerHomeViewController: function (viewModel, customerService) {
            var validation = viewModel && customerService;

            if (validation) {
                viewModel.saveStatus = false;
                viewModel.customerRecord = {
                    id: customerService.generateNewCustomerId(),
                    status: true
                };

                viewModel.phoneExpression = /^\d{5}-\d{5}$/;
                viewModel.creditLimits = {
                    minimum: MINIMUM_CREDIT,
                    maximum: MAXIMUM_CREDIT
                };

                viewModel.saveCustomerRecord = function (customerForm) {
                    if (customerForm && customerForm.$valid) {
                        customerService.saveCustomerDetail(viewModel.customerRecord)
                            .then(
                                function (data) {
                                    if (data && data.status) {
                                        viewModel.saveStatus = data.status;
                                    }
                                },
                                function (error) {
                                    viewModelErrorUtils.handleError(viewModel, error);
                                });
                    }
                };
            }
        }
    };

    module.exports = definitions;
})();