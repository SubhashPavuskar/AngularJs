(function () {
    'use strict';

    var viewModelErrorUtils = require('../../utilities/viewmodel-error-utils');

    var definitions = {
        crmSystemHomeViewController: function (viewModel, customerService) {
            var validation = viewModel && customerService;

            if (validation) {
                customerService.getAllCustomers()
                    .then(
                        function (data) {
                            if (data) {
                                viewModel.customers = data;
                            }
                        },
                        function (error) {
                            viewModelErrorUtils.handleError(viewModel, error);
                        });
            }
        },
        crmSystemDashboardHomeViewController: function (viewModel,
                                                        promiseService, stateParameters,
                                                        customerService, orderService,
                                                        transformationService) {
            var validation = viewModel && promiseService &&
                stateParameters && customerService && orderService && transformationService;

            if (validation) {
                var selectedCustomerId = stateParameters.customerId;

                if (selectedCustomerId) {
                    var customerPromise = customerService.getCustomerDetail(selectedCustomerId);
                    var ordersPromise = orderService.getOrdersByCustomerId(selectedCustomerId);

                    promiseService.all([customerPromise, ordersPromise])
                        .then(
                            function (results) {
                                if (results) {
                                    viewModel.customer = results[0];
                                    viewModel.orders = results[1];
                                    viewModel.ordersChartData = transformationService.transform(results[1]);
                                }
                            },
                            function (error) {
                                viewModelErrorUtils.handleError(viewModel, error);
                            });
                }
            }
        },
        stockViewerController: function (viewModel, timer, browser, stockQuoteService) {
            var validation = viewModel && timer && browser && stockQuoteService;

            if (validation) {
                var timerObject = null;
                var initializeQuotation = function () {
                    var quotation = stockQuoteService.getStockQuote(viewModel.customerDetail.name);

                    viewModel.quotation = quotation;
                    viewModel.stockQuoteHistory.unshift({
                        time: new Date(),
                        quotation: quotation
                    });
                };

                viewModel.stockQuoteHistory = [];

                viewModel.$watch('refreshInterval',
                    function (newValue) {
                        if (newValue) {
                            if (timerObject) {
                                browser.clearInterval(timerObject.$$intervalId);
                            }

                            timerObject = timer(initializeQuotation, viewModel.refreshInterval);
                        }
                    });
            }
        }
    };

    module.exports = definitions;
})();