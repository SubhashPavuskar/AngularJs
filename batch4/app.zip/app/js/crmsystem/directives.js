(function () {
    'use strict';

    require('./config');
    require('./controllers');

    var ngModuleName = 'com.gs.modules.crmsystem.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.config',
            'com.gs.modules.crmsystem.controllers'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var thumbnailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerThumbnailViewerDirective
        ];

    var customerDetailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerDetailViewerDirective
        ];

    var customerSearchPanelDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerSearchPanelDirective
        ];

    var orderViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.orderViewerDirective
        ];

    var stockViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.stockViewerDirective
        ];

    var stockQuoteHistoryViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.stockQuoteHistoryViewerDirective
        ];

    moduleObject.directive('customerThumbnailViewer', thumbnailViewerDirectiveDefinition);
    moduleObject.directive('customerDetailViewer', customerDetailViewerDirectiveDefinition);
    moduleObject.directive('customerSearchPanel', customerSearchPanelDirectiveDefinition);
    moduleObject.directive('orderViewer', orderViewerDirectiveDefinition);
    moduleObject.directive('stockViewer', stockViewerDirectiveDefinition);
    moduleObject.directive('stockQuoteHistoryViewer', stockQuoteHistoryViewerDirectiveDefinition);
})();