(function () {
    'use strict';

    require('./config');
    require('./directives');
    require('./services');
    require('./interceptors');

    var ngModuleName = 'com.gs.modules.security';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'com.gs.modules.security.config',
            'com.gs.modules.security.services',
            'com.gs.modules.security.directives',
            'com.gs.modules.security.interceptors'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var securityModuleInitializerDefinition =
        [
            '$rootScope',
            '$log',
            'authenticationStorageService',
            definitions.initializeSecurityModule
        ];

    moduleObject.run(securityModuleInitializerDefinition);
})();