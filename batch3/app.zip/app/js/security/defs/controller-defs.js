(function () {
    'use strict';

    var viewModelErrorUtils = require('../../utilities/viewmodel-error-utils');

    var definitions = {
        loginPanelController: function (viewModel, globalViewModel, authService, authStorageService) {
            var validation = viewModel && globalViewModel && authStorageService && authService;

            if (validation) {
                viewModel.authStatus = false;

                viewModel.login = function () {
                    authService.authenticate(viewModel.userName, viewModel.password)
                        .then(
                            function (data) {
                                if (data && data.token) {
                                    authStorageService.setAuthToken(data.token);

                                    viewModel.authStatus = true;
                                    globalViewModel.isAuthenticated = true;
                                }
                            },
                            function (error) {
                                viewModelErrorUtils.handleError(viewModel, error);
                            });
                };

                viewModel.logout = function () {
                    authStorageService.unsetAuthToken();

                    viewModel.authStatus = false;
                    globalViewModel.isAuthenticated = false;
                };
            }
        }
    };

    module.exports = definitions;
})();