(function () {
    'use strict';

    var definitions = {
        initializeSecurityModule: function (globalViewModel, logger, authenticationStorageService) {
            var validation = globalViewModel && logger && authenticationStorageService;

            if (validation) {
                var isAuthTokenAvailable = authenticationStorageService.isAuthTokenAvailable();

                if (isAuthTokenAvailable) {
                    authenticationStorageService.unsetAuthToken();
                }

                globalViewModel.isAuthenticated = false;
                logger.info('Security Module Initialized!');
            }
        }
    };

    module.exports = definitions;
})();