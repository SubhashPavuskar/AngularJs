(function () {
    'use strict';

    var HTTP_AUTHORIZATION_PREFIX = "Bearer";
    var DELIMITER = ' ';

    var definitions = {
        authorizationInterceptorService: function (authenticationStorageService) {
            var serviceDefinition = {};

            if (authenticationStorageService) {
                serviceDefinition = {
                    request: function (configuration) {
                        configuration.headers = configuration.headers || {};

                        if (authenticationStorageService.isAuthTokenAvailable()) {
                            var authToken = authenticationStorageService.getAuthToken();

                            configuration.headers.Authorization =
                                HTTP_AUTHORIZATION_PREFIX + DELIMITER + authToken;
                        }

                        return configuration;
                    }
                };
            }

            return serviceDefinition;
        },
        configureHttpInterceptors: function (httpProvider) {
            if (httpProvider) {
                httpProvider.interceptors.push('authorizationInterceptorService');
            }
        }
    };

    module.exports = definitions;
})();