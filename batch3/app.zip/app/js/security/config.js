(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.security.config';
    var angular = require('angular');
    var ngDependencies = [];
    var moduleObject = angular.module(ngModuleName, ngDependencies);

    moduleObject.constant('authTokenInfo', {
        tokenKey: 'gsjwt'
    });

    moduleObject.constant('authServiceUrl', '/authenticate');

    moduleObject.constant('securityDirTemplateUrls', {
        loginPanel: 'js/security/partials/directives/login-panel.html'
    });
})();