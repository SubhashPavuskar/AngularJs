(function () {
    'use strict';

    require('./config');
    require('./controllers');

    var ngModuleName = 'com.gs.modules.security.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.security.config',
            'com.gs.modules.security.controllers'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var loginPanelDirectiveDefinition =
        [
            'securityDirTemplateUrls',
            definitions.loginPanelDirective
        ];

    moduleObject.directive('loginPanel', loginPanelDirectiveDefinition);
})();