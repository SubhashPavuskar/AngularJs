(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.crmsystem.config';
    var angular = require('angular');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    moduleObject.constant('crmSystemViewTemplateUrls', {
        crmSystemHome: 'js/crmsystem/partials/views/crm-system-home-view.html'
    });

    moduleObject.constant('crmSystemDirTemplateUrls', {
        customerThumbnailViewer: 'js/crmsystem/partials/directives/customer-thumbnail-viewer.html',
        customerDetailViewer: 'js/crmsystem/partials/directives/customer-detail-viewer.html'
    });

    moduleObject.constant('crmSystemServiceUrls', {
        baseUrl: '/api',
        customers: {
            baseUrl: '/customers',
            queryAndSave: '/:customerId'
        },
        orders: {
            baseUrl: '/orders',
            queryAndSave: '/:customerId'
        }
    });

    moduleObject.constant('photoBaseUrl', '/images/people');
})();