(function () {
    'use strict';

    var definitions = {
        customerService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var customerServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.customers.baseUrl + serviceUrls.customers.queryAndSave;
                var customerRestService = restService(customerServiceUrl);

                serviceDefinition = {
                    getCustomers: function () {
                        return customerRestService.query().$promise;
                    },
                    getCustomerDetail: function (id) {
                        return customerRestService.get({
                            customerId: id
                        }).$promise;
                    },
                    saveCustomerDetail: function (customerDetail) {
                        return customerRestService.save(customerDetail).$promise;
                    },
                    generateNewCustomerId: function () {
                        var MIN_ID = 11;
                        var MAX_ID = 21;

                        return Math.floor(
                            Math.random() * (MAX_ID - MIN_ID) + MIN_ID);
                    }
                };

            }

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();