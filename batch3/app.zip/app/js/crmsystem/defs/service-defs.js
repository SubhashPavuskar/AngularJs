(function () {
    'use strict';

    var DEFAULT_CHART_TYPE = 'line';
    var MIN_QUOTE = 100;
    var MAX_QUOTE = 1000;

    var definitions = {
        customerService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var customerServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.customers.baseUrl + serviceUrls.customers.queryAndSave;
                var customerRestService = restService(customerServiceUrl);

                serviceDefinition = {
                    getCustomers: function () {
                        return customerRestService.query().$promise;
                    },
                    getCustomerDetail: function (id) {
                        return customerRestService.get({
                            customerId: id
                        }).$promise;
                    },
                    saveCustomerDetail: function (customerDetail) {
                        return customerRestService.save(customerDetail).$promise;
                    },
                    generateNewCustomerId: function () {
                        var MIN_ID = 11;
                        var MAX_ID = 21;

                        return Math.floor(
                            Math.random() * (MAX_ID - MIN_ID) + MIN_ID);
                    }
                };

            }

            return serviceDefinition;
        },
        orderService: function (restService, serviceUrls) {
            var serviceDefinition = {};
            var validation = restService && serviceUrls;

            if (validation) {
                var orderServiceUrl = serviceUrls.baseUrl +
                    serviceUrls.orders.baseUrl + serviceUrls.orders.queryAndSave;
                var orderRestService = restService(orderServiceUrl);

                serviceDefinition = {
                    getOrdersByCustomerId: function (customerId) {
                        return orderRestService.query({
                            customerId: customerId
                        }).$promise;
                    }
                };
            }

            return serviceDefinition;
        },
        chartDataTransformationService: function () {
            var serviceDefinition = {
                transform: function (orders, chartType) {
                    chartType = chartType || DEFAULT_CHART_TYPE;

                    var ordersChartData = [];

                    if (orders) {
                        var orderIds = ['Order Id'];
                        var orderAmounts = ['Order Amount'];

                        for (var index in orders) {
                            var order = orders[index];

                            if (order && order.orderId && order.amount) {
                                orderIds.push(order.orderId);
                                orderAmounts.push(order.amount);
                            }
                        }

                        ordersChartData = [orderIds, orderAmounts];
                    }

                    return ordersChartData;
                }
            };

            return serviceDefinition;
        },
        stockQuoteService: function () {
            var serviceDefinition = {
                getStockQuote: function (customerName) {
                    var quotation = 0;

                    if (customerName) {
                        quotation = Math.floor(
                            Math.random() * (MAX_QUOTE - MIN_QUOTE) + MIN_QUOTE);
                    }

                    return quotation;
                }
            };

            return serviceDefinition;
        }
    };

    module.exports = definitions;
})();