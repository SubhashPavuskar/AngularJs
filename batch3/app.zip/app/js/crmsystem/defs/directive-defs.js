(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        customerThumbnailViewerDirective: function (templateUrls) {
            var scope = {
                customerInfo: '='
            };

            return directiveUtils.createDirective(templateUrls.customerThumbnailViewer, scope);
        },
        customerDetailViewerDirective: function (templateUrls) {
            var scope = {
                customerDetail: '='
            };

            return directiveUtils.createDirective(templateUrls.customerDetailViewer, scope);
        },
        customerSearchPanelDirective: function (templateUrls) {
            var scope = {
                searchString: '='
            };

            return directiveUtils.createDirective(templateUrls.customerSearchPanel, scope);
        },
        orderViewerDirective: function (templateUrls) {
            var scope = {
                ordersList: '='
            };

            return directiveUtils.createDirective(templateUrls.orderViewer, scope);
        },
        stockViewerDirective: function (templateUrls) {
            var scope = {
                customerDetail: '=',
                refreshInterval: '='
            };

            var controller = 'stockViewerController';

            return directiveUtils.createDirective(templateUrls.stockViewer, scope, controller);
        },
        stockQuoteHistoryViewerDirective: function (templateUrls) {
            var scope = {
                historyList: '='
            };

            return directiveUtils.createDirective(templateUrls.stockQuoteHistoryViewer, scope);
        },
        dashboardSwitchPanelDirective: function (templateUrls) {
            var scope = null;
            var controller = 'dashboardSwitchPanelController';

            return directiveUtils.createDirective(templateUrls.dashboardSwitchPanel, scope, controller);
        },
        creditLimitValidationDirective: function () {
            var templateUrl = null;
            var scope = {
                minimumLimit: '=',
                maximumLimit: '='
            };

            var directive = directiveUtils.createDirective(templateUrl, scope);

            directive.require = 'ngModel';
            directive.link = function (viewModel, element, attributes, model) {
                model.$validators.gsCreditLimitValidation =
                    function (modelValue) {
                        var status = false;

                        if (modelValue) {
                            status = modelValue >= viewModel.minimumLimit &&
                                modelValue <= viewModel.maximumLimit;
                        }

                        return status;
                    };
            };

            return directive;
        }
    };

    module.exports = definitions;
})();