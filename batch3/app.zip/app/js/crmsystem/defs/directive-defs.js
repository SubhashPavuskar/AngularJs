(function () {
    'use strict';

    var directiveUtils = require('../../utilities/directive-utils');

    var definitions = {
        customerThumbnailViewerDirective: function (templateUrls) {
            var scope = {
                customerInfo: '='
            };

            return directiveUtils.createDirective(templateUrls.customerThumbnailViewer, scope);
        },
        customerDetailViewerDirective: function (templateUrls) {
            var scope = {
                customerDetail: '='
            };

            return directiveUtils.createDirective(templateUrls.customerDetailViewer, scope);
        }
    };

    module.exports = definitions;
})();