(function () {
    'use strict';

    var DEFAULT_FORMAT = "JPG";

    var definitions = {
        photoUrlFilter: function (photoBaseUrl) {
            var filterLogic = function (bindingValue, format) {
                var url = null;

                format = format || DEFAULT_FORMAT;

                if (bindingValue) {
                    url = photoBaseUrl + '/Customer' + bindingValue + "." + format;
                }

                return url;
            };

            return filterLogic;
        }
    };

    module.exports = definitions;
})();