(function () {
    'use strict';

    var definitions = {
        initializeCrmSystemModule: function (logger, globalViewModel) {
            var validation = logger && globalViewModel;

            if (validation) {
                globalViewModel.crmSystemInitTime = new Date();
                globalViewModel.isAuthenticationRequired = true;

                logger.info('Crm System Module Initialized!');
            }
        }
    };

    module.exports = definitions;
})();