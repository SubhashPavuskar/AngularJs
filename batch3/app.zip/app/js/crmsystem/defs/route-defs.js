(function () {
    'use strict';

    var routerUtils = require('../../utilities/router-utils');

    var states = {
        crmSystemHome: {
            name: 'crmSystemHome',
            url: '/crm-system-home',
            controller: 'crmSystemHomeViewController'
        },
        crmSystemDashboardHome: {
            name: 'crmSystemDashboardHome',
            url: '/crm-system-dashboard-home/:customerId',
            controller: 'crmSystemDashboardHomeViewController'
        },
        newCustomerHome: {
            name: 'newCustomerHome',
            url: '/new-customer-home',
            controller: 'newCustomerHomeViewController'
        }
    };

    var definitions = {
        configureCrmSystemRouter: function (stateProvider, templateUrls) {
            var validation = stateProvider && templateUrls;

            if (validation) {
                routerUtils.configureRouter(stateProvider, states, templateUrls);
            }
        }
    };

    module.exports = definitions;
})();