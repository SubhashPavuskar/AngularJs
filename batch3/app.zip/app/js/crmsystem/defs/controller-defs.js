(function () {
    'use strict';

    var viewModelErrorUtils = require('../../utilities/viewmodel-error-utils');

    var definitions = {
        crmSystemHomeViewController: function (viewModel, customerService) {
            var validation = viewModel && customerService;

            if (validation) {
                customerService.getCustomers()
                    .then(
                        function (data) {
                            if (data) {
                                viewModel.customers = data;
                            }
                        },
                        function (error) {
                            viewModelErrorUtils.handleError(viewModel, error);
                        });
            }
        },
        crmSystemDashboardHomeViewController: function (viewModel,
                                                        stateParameters, promiseService,
                                                        customerService, orderService,
                                                        chartDataTransformationService) {
            var validation = viewModel && stateParameters && promiseService &&
                customerService && orderService && chartDataTransformationService;

            if (validation) {
                var selectedCustomerId = stateParameters.customerId;

                if (selectedCustomerId) {
                    var customerPromise = customerService.getCustomerDetail(selectedCustomerId);
                    var orderPromise = orderService.getOrdersByCustomerId(selectedCustomerId);

                    promiseService.all([customerPromise, orderPromise])
                        .then(
                            function (results) {
                                if (results) {
                                    viewModel.customer = results[0];
                                    viewModel.orders = results[1];
                                    viewModel.ordersChartData = chartDataTransformationService.transform(results[1]);
                                }
                            },
                            function (error) {
                                viewModelErrorUtils.handleError(viewModel, error);
                            });
                }
            }
        }
    };

    module.exports = definitions;
})();