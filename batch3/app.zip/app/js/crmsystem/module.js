(function () {
    'use strict';

    require('ngRadialGauge');
    require('../charting/module');
    require('./routes');
    require('./directives');
    require('./filters');

    var ngModuleName = 'com.gs.modules.crmsystem';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'ngRadialGauge',
            'com.gs.modules.charting',
            'com.gs.modules.crmsystem.routes',
            'com.gs.modules.crmsystem.directives',
            'com.gs.modules.crmsystem.filters'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var moduleInitializerDefinition =
        [
            '$log',
            '$rootScope',
            definitions.initializeCrmSystemModule
        ];

    moduleObject.run(moduleInitializerDefinition);
})();