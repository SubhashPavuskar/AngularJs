(function () {
    'use strict';

    require('./routes');
    require('./directives');
    require('./filters');

    var ngModuleName = 'com.gs.modules.crmsystem';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.routes',
            'com.gs.modules.crmsystem.directives',
            'com.gs.modules.crmsystem.filters'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var moduleInitializerDefinition =
        [
            '$log',
            '$rootScope',
            definitions.initializeCrmSystemModule
        ];

    moduleObject.run(moduleInitializerDefinition);
})();