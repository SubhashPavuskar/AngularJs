(function () {
    'use strict';

    require('./config');

    var ngModuleName = 'com.gs.modules.crmsystem.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.config'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var customerThumbnailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerThumbnailViewerDirective
        ];

    var customerDetailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerDetailViewerDirective
        ];

    var customerSearchPanelDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerSearchPanelDirective
        ];

    moduleObject.directive('customerThumbnailViewer', customerThumbnailViewerDirectiveDefinition);
    moduleObject.directive('customerDetailViewer', customerDetailViewerDirectiveDefinition);
    moduleObject.directive('customerSearchPanel', customerSearchPanelDirectiveDefinition);
})();