(function () {
    'use strict';

    require('./config');
    require('./controllers');

    var ngModuleName = 'com.gs.modules.crmsystem.directives';
    var angular = require('angular');
    var definitions = require('./defs/directive-defs');

    var ngDependencies =
        [
            'com.gs.modules.crmsystem.config',
            'com.gs.modules.crmsystem.controllers'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var customerThumbnailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerThumbnailViewerDirective
        ];

    var customerDetailViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerDetailViewerDirective
        ];

    var customerSearchPanelDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.customerSearchPanelDirective
        ];

    var orderViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.orderViewerDirective
        ];

    var stockViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.stockViewerDirective
        ];

    var stockQuoteHistoryViewerDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.stockQuoteHistoryViewerDirective
        ];

    var dashboardSwitchPanelDirectiveDefinition =
        [
            'crmSystemDirTemplateUrls',
            definitions.dashboardSwitchPanelDirective
        ];

    var creditLimitValidationDirectiveDefinition =
        [
          definitions.creditLimitValidationDirective
        ];

    moduleObject.directive('customerThumbnailViewer', customerThumbnailViewerDirectiveDefinition);
    moduleObject.directive('customerDetailViewer', customerDetailViewerDirectiveDefinition);
    moduleObject.directive('customerSearchPanel', customerSearchPanelDirectiveDefinition);
    moduleObject.directive('orderViewer', orderViewerDirectiveDefinition);
    moduleObject.directive('stockViewer', stockViewerDirectiveDefinition);
    moduleObject.directive('stockQuoteHistoryViewer', stockQuoteHistoryViewerDirectiveDefinition);
    moduleObject.directive('dashboardSwitchPanel', dashboardSwitchPanelDirectiveDefinition);
    moduleObject.directive('gsCreditLimitValidation', creditLimitValidationDirectiveDefinition);
})();