(function () {
    'use strict';

    require('jquery-browserify');
    require('bootstrap');
    require('./common/module');

    var ngModuleName = 'com.gs.app';
    var angular = require('angular');
    var definitions = require('./defs/main-defs');

    var ngDependencies =
        [
            'com.gs.modules.common'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var appInitializerDefinition =
        [
            '$log',
            '$rootScope',
            definitions.initializeApp
        ];

    moduleObject.run(appInitializerDefinition);

    definitions.bootstrapApp(ngModuleName);
})();