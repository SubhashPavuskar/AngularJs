(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.push-notifications.services';
    var angular = require('angular');
    var definitions = require('./defs/service-defs');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var notificationUrlProviderServiceDefinition =
        [
            '$window',
            definitions.notificationUrlProviderService
        ];

    var pushNotificationServiceDefinition =
        [
            'notificationUrlProviderService',
            definitions.pushNotificationService
        ];

    moduleObject.factory('notificationUrlProviderService', notificationUrlProviderServiceDefinition);
    moduleObject.service('pushNotificationService', pushNotificationServiceDefinition);
})();