(function () {
    'use strict';

    require('./services');

    var ngModuleName = 'com.gs.modules.push-notifications';
    var angular = require('angular');
    var definitions = require('./defs/module-defs');

    var ngDependencies =
        [
            'com.gs.modules.push-notifications.services'
        ];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    var moduleInitializerDefinition =
        [
            '$log',
            definitions.initializeModule
        ];

    moduleObject.run(moduleInitializerDefinition);
})();