(function () {
    'use strict';

    var PROTOCOL_DELIMITER = "//";
    var PORT_DELIMITER = ":";

    var socketIOClient = require('socket.io-client');

    function PushNotificationService(notificationUrlProvider) {
        var registeredCallbacks = {};

        if (notificationUrlProvider) {
            var notificationUrl = notificationUrlProvider.getNotificationUrl();

            this.registerCallback = function (eventName, callback) {
                var callbacks = registeredCallbacks[eventName];

                if (!callbacks) {
                    callbacks = [];

                    var socketClient = socketIOClient.connect(notificationUrl);

                    socketClient.on(eventName,
                        function (notificationData) {
                            for (var index in callbacks) {
                                var callbackItem = callbacks[index];

                                callbackItem(notificationData);
                            }
                        });
                }

                callbacks.push(callback);
            };
        }
    }

    var definitions = {
        notificationUrlProviderService: function (browser) {
            var serviceDefinition = {};

            if (browser) {
                var locationService = browser.location;

                serviceDefinition = {
                    getNotificationUrl: function () {
                        var notificationUrl = locationService.protocol +
                            PROTOCOL_DELIMITER + locationService.hostname +
                            PORT_DELIMITER + locationService.port;

                        return notificationUrl;
                    }
                };
            }

            return serviceDefinition;
        },
        pushNotificationService: PushNotificationService
    };

    module.exports = definitions;
})();