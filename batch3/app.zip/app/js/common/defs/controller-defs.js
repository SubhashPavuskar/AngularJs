(function () {
    'use strict';

    var viewModelErrorUtils = require('../../utilities/viewmodel-error-utils');

    var definitions = {
        aboutViewController: function (viewModel) {
        },
        homeViewController: function (viewModel, subHeadingService) {
            var validation = viewModel && subHeadingService;

            if (validation) {
                subHeadingService.getSubHeadings()
                    .then(
                        function (data) {
                            if (data) {
                                viewModel.subHeadings = data;
                            }
                        },
                        function (error) {
                            viewModelErrorUtils.handleError(viewModel, error);
                        });
            }
        }
    };

    module.exports = definitions;
})();