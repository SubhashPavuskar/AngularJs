(function () {
    'use strict';

    var routerUtils = require('../../utilities/router-utils');

    var states = {
        home: {
            name: 'home',
            url: '/home',
            controller: 'homeViewController'
        },
        about: {
            name: 'about',
            url: '/about-us',
            controller: 'aboutViewController'
        }
    };

    var definitions = {
        configureCommonRouter: function (stateProvider, urlRouterProvider, templateUrls) {
            var validation = stateProvider && urlRouterProvider && templateUrls;

            if (validation) {
                routerUtils.configureRouter(stateProvider, states, templateUrls);

                urlRouterProvider.otherwise(states.home.name);
            }
        }
    };

    module.exports = definitions;
})();