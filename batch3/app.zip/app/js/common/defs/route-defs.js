(function () {
    'use strict';

    var states = {
        home: {
            name: 'home',
            url: '/home',
            controller: 'homeViewController'
        },
        about: {
            name: 'about',
            url: '/about-us',
            controller: 'aboutViewController'
        }
    };

    var definitions = {
        configureCommonRouter: function (stateProvider, urlRouterProvider, templateUrls) {
            var validation = stateProvider && urlRouterProvider && templateUrls;

            if (validation) {
                for (var state in states) {
                    if (state) {
                        (function() {
                            var currentState = state;
                            stateProvider.state(states[currentState].name, {
                                url: states[currentState].url,
                                templateUrl: function () {
                                    return templateUrls[currentState];
                                },
                                controller: states[currentState].controller
                            });
                        })();
                    }
                }

                urlRouterProvider.otherwise(states.home.name);
            }
        }
    };

    module.exports = definitions;
})();