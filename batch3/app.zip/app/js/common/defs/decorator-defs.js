(function () {
    'use strict';

    var CACHE_CONTAINER = 'subHeadingCacheContainer';
    var CACHE_KEY = 'subHeadings';

    function decorateSubHeadingService(delegateService, cacheFactory, promiseService) {
        var validation = delegateService && cacheFactory && promiseService;

        if (validation) {
            var realServiceReference = delegateService.getSubHeadings;
            var cacheContainer = cacheFactory(CACHE_CONTAINER);

            delegateService.getSubHeadings = function () {
                var cache = cacheContainer.get(CACHE_KEY);
                var deferred = promiseService.defer();

                if (cache) {
                    deferred.resolve(cache);
                } else {
                    realServiceReference().then(
                        function (data) {
                            if (data) {
                                cacheContainer.put(CACHE_KEY, data);

                                deferred.resolve(data);
                            } else deferred.reject(data);
                        },
                        function (error) {
                            deferred.reject(error);
                        });
                }

                return deferred.promise;
            };
        }

        return delegateService;
    }

    var definitions = {
        configureDecorators: function (provideService) {
            if (provideService) {
                var subHeadingServiceDecoratorDefinition =
                    [
                        '$delegate',
                        '$cacheFactory',
                        '$q',
                        decorateSubHeadingService
                    ];

                provideService.decorator('subHeadingService', subHeadingServiceDecoratorDefinition);
            }
        }
    };

    module.exports = definitions;
})();