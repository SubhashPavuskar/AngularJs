(function () {
    'use strict';

    var ngModuleName = 'com.gs.modules.common.config';
    var angular = require('angular');
    var ngDependencies = [];

    var moduleObject = angular.module(ngModuleName, ngDependencies);

    moduleObject.constant('commonDirTemplateUrls', {
        header: 'js/common/partials/directives/header.html',
        navigation: 'js/common/partials/directives/navigation.html',
        subHeadingViewer: 'js/common/partials/directives/sub-heading-viewer.html'
    });

    moduleObject.constant('commonViewTemplateUrls', {
        home: 'js/common/partials/views/home.html'
    });

    moduleObject.constant('subHeadingServiceUrl', 'data/data.json');
})();